import pandas as pd,re
p='/app/input_files/'
ids=['11341980_23','3672856_34','81100_69','3612156_42','6931942_17','5655150_280','3385333_19','11341177_13','6139418_72','11644460_32','1313717_86','12122490_155','5861465_62','6215707_64','8210237_68']
a=pd.read_csv(p+'legal_reasoning_annotations.csv'); sel=a[a.section_id.isin(ids)].copy();sel['cid']=sel.section_id.str.split('_').str[0];print(sel[['section_id','name','paragraph']].to_string(index=False,max_colwidth=80))
for f in ['sc_data.csv','reasoning.csv']:
 print('\n',f)
 for ch in pd.read_csv(p+f,chunksize=3500,usecols=['case_url','case_name','opinion_text','opinion_type','project_opinion_id','year']):
  m=ch[ch.case_url.str.extract(r'/cases/(\d+)/',expand=False).isin(sel.cid)]
  for _,r in m.iterrows():
   q=sel[sel.cid==re.search(r'/cases/(\d+)/',r.case_url).group(1)].iloc[0];text=str(r.opinion_text);phrase=str(q.paragraph)[:85]; pos=text.find(phrase);print(q.section_id,r.project_opinion_id,r.opinion_type,'length',len(text),'pos',pos,'first',text[:65].replace('\n',' '))
