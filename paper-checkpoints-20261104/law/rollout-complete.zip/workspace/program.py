import subprocess
r=subprocess.run(["/bin/bash","-lc","python - <<'PY'\np='/work/output/review.py';s=open(p).read().replace('原件：sc_data.csv / reasoning.csv，{rec[\\'project_opinion_id\\']}，{rec[\\'opinion_type\\']}，字符位','原件：reasoning.csv.opinion_text（sc_data.csv同意见键可交叉查验），{rec[\\'project_opinion_id\\']}，{rec[\\'opinion_type\\']}，字符位');s=s.replace('offset为sc_data/reasoning原意见0起字符位置','offset为reasoning.csv原意见0起字符位置')\nopen(p,'w').write(s)\nPY\ncd /work/output && python review.py >/work/run.log 2>&1; ls -lh /work/output; tail -3 /work/run.log"],timeout=120)
raise SystemExit(r.returncode)
