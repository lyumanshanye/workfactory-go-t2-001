import pandas as pd
import numpy as np
import re
import os
from nltk.tokenize import word_tokenize

def clean_text(text):
    """
    Clean strings with multiple numbers and asterisks. 
    """
    text = re.sub("(\*+\d+)", "", text)
    text = re.sub("(\.\d+)", ".", text)
    return text

def find_and_replace_citations(text):
    """
    Use the eyecite package to find citations of court cases. 
    For every citation identified, replace with "CITE".
    """
    try:
        citations = get_citations(text)
        new_text = text
        for citation in citations:
            new_text = re.sub(citation.matched_text(), "CITE", new_text)
    except:
        new_text = text
    return new_text


def split_to_paragraphs(df):
    """
    Split at the paragraph level and keep only paragraphs greater than 200 characters long. 
    """
    paragraph_df = df.assign(split_text=df['opinion_text'].str.split('\n')).explode('split_text')
    paragraph_df = paragraph_df.loc[paragraph_df['split_text'].str.len() > 200]
    paragraph_df = paragraph_df.rename(columns = {"split_text": "paragraph"})
    paragraph_df['sequence']=paragraph_df.groupby('project_opinion_id').cumcount()
    paragraph_df["section_id"] = paragraph_df.apply(lambda x: str(x["project_opinion_id"]) + "_" + str(x["sequence"]), axis = 1)
    paragraph_df["par_word_count"] = paragraph_df.apply(lambda x: len(word_tokenize(x["paragraph"])), axis = 1)
    return paragraph_df

def count_grand_seeds(df): 
    """
    Return words/phrases found in paragraph that are likely grand. 
    """
    p_report_phrases = ["conference report", "committee report", "senate report", "house report", "assembly report"]
    p_talk_words = ["senate hearing", "house hearing", "assembly hearing", "committee hearing", "conference hearing", "floor debate"]
    p_misc_words = ["legislative history", "history of the legislation", "conference committee", "joint committee", "senate committee", "house committee", "assembly committee"]
    p_social_words = ["legislative purpose", "congressional purpose", "purpose of congress", "purpose of the legislature", "social", "society"]

    p_words = p_report_phrases + p_talk_words + p_misc_words + p_social_words

    words_in_paragraph = [term for term in p_words if term in df["paragraph"].lower()]

    return words_in_paragraph 

def count_formal_seeds(df): 
    """
    Return words/phrases found in paragraph that are likely formal. 
    """
    t_dict_words = ["dictionary", "dictionarium", "liguae britannicae", "world book", "funk \& wagnalls"]
    t_grammar_words = ["expressio", "expresio", "inclusio", "noscitur a sociis", "noscitur a socis", "ejusdem generis", "last antecedent", "plain language"]
    t_substantive_words = ["whole act", "whole-act", "whole code", "whole-code", "in pari materia", "meaningful variation", "consistent usage", "surplusage", "superfluit"]
    t_formal_words = ["plain meaning", "ordinary meaning", "word"]

    t_words = t_dict_words + t_grammar_words + t_substantive_words + t_formal_words

    words_in_paragraph = [term for term in t_words if term in df["paragraph"].lower()]

    return words_in_paragraph 

def main():
    df = pd.read_csv(os.path.join(os.getcwd(), '..', 'data', 'sc_data.csv'))

    df["opinion_text"] = df["opinion_text"].astype(str).apply(clean_text)
    df["opinion_text"] = df["opinion_text"].apply(find_and_replace_citations)

    paragraph_df = split_to_paragraphs(df)

    paragraph_df["formal_words"] = paragraph_df.apply(count_formal_seeds, axis = 1)
    paragraph_df["grand_words"] = paragraph_df.apply(count_grand_seeds, axis = 1)
    paragraph_df["grand_count"] = paragraph_df.apply(lambda x: len(x["grand_words"]), axis = 1)
    paragraph_df["formal_count"] = paragraph_df.apply(lambda x: len(x["formal_words"]), axis = 1)

    paragraph_df["diff"] = paragraph_df["formal_count"] - paragraph_df["grand_count"] 
    paragraph_df["diff_percent"] = paragraph_df["diff"] / paragraph_df["par_word_count"]

    paragraph_df.to_csv(os.path.join(os.getcwd(), 'lr-data', 'data_for_predictions.csv'))

if __name__ == "__main__":
    main()