import json,os,socket,ctypes
from pathlib import Path
import docx,openpyxl,numpy
checks={"uid_1000":os.getuid()==1000,"source_readable":Path("/input/source.txt").read_text()=="ACTUAL ISOLATION PROBE"}
checks["host_project_absent"]=not Path("/inspire").exists()
checks["host_credentials_absent"]=not Path("/run/workfactory").exists() and not Path("/root/.ssh").exists()
try:Path("/input/source.txt").write_text("changed");checks["source_readonly"]=False
except OSError:checks["source_readonly"]=True
try:Path("/work/input/source.txt").write_text("changed");checks["author_input_readonly"]=False
except OSError:checks["author_input_readonly"]=True
try:socket.create_connection(("1.1.1.1",443),timeout=1);checks["network_isolated"]=False
except OSError:checks["network_isolated"]=True
libc=ctypes.CDLL(None)
class H(ctypes.Structure):_fields_=[("version",ctypes.c_uint),("pid",ctypes.c_int)]
class D(ctypes.Structure):_fields_=[("effective",ctypes.c_uint),("permitted",ctypes.c_uint),("inheritable",ctypes.c_uint)]
h=H(0x20080522,0);d=(D*2)();assert libc.capget(ctypes.byref(h),ctypes.byref(d))==0
checks["no_effective_capabilities"]=all(x.effective==0 and x.permitted==0 for x in d)
checks["no_new_privs"]=libc.prctl(39,0,0,0,0)==1
checks["host_proc_absent"]=not Path("/proc/self").exists()
Path("/work/probe.json").write_text(json.dumps(checks,indent=2))
print(json.dumps(checks))
assert all(checks.values()),checks
