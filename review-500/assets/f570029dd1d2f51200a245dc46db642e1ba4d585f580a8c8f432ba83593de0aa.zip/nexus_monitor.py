"""Offline, deterministic indirect-tax nexus monitor."""
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

_CENT = Decimal("0.01")


def _money(value):
    try:
        amount = Decimal(str(value).strip())
    except (InvalidOperation, AttributeError, ValueError) as exc:
        raise ValueError(f"malformed monetary amount: {value!r}") from exc
    if not amount.is_finite():
        raise ValueError(f"malformed monetary amount: {value!r}")
    return amount


def _rounded(value):
    return float(value.quantize(_CENT, rounding=ROUND_HALF_UP))


def _iso_date(value):
    try:
        return date.fromisoformat(str(value))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid ISO order date: {value!r}") from exc


def _received_key(value):
    if value in (None, ""):
        return datetime.min
    text = str(value)
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if parsed.tzinfo is not None:
            parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
        return parsed
    except ValueError as exc:
        raise ValueError(f"invalid received_at timestamp: {value!r}") from exc


def _flag(value):
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"true", "1", "yes", "y"}


def _record_key(record):
    """Stable final fallback for completely identical duplicate timestamps/sources."""
    return tuple(sorted((str(key), str(value)) for key, value in record.items()))


def monitor(records, rules, as_of_date, prior_alerts=None):
    """Aggregate eligible orders and return alerts, summaries, and assumptions."""
    max_records = int(rules.get("max_records", 100000))
    if len(records) > max_records:
        raise ValueError(f"record limit exceeded: {len(records)} > {max_records}")
    as_of = _iso_date(as_of_date)
    jurisdictions = {}
    for item in rules.get("jurisdictions", []):
        state = str(item.get("state", "")).strip()
        if state:
            jurisdictions[state] = {
                "name": item.get("name", state),
                "threshold": _money(item.get("threshold", 0)),
                "facilitator_sales_count": bool(item.get("facilitator_sales_count", False)),
                "currency": item.get("currency", "USD"),
            }
    exclusions = {}
    def exclude(reason):
        exclusions[reason] = exclusions.get(reason, 0) + 1

    candidates_by_id = {}
    for raw in records:
        if not isinstance(raw, dict):
            exclude("invalid_record")
            continue
        missing = [key for key in ("order_id", "order_date", "state", "amount")
                   if raw.get(key) in (None, "")]
        if missing:
            for key in missing:
                exclude(f"missing_{key}")
            continue
        amount = _money(raw.get("amount"))
        order_id = str(raw.get("order_id")).strip()
        state = str(raw.get("state")).strip()
        order_date = _iso_date(raw.get("order_date"))
        received = _received_key(raw.get("received_at"))
        source = str(raw.get("source", ""))
        candidate = (received, source, _record_key(raw), raw, amount, order_date, state)
        candidates_by_id.setdefault(order_id, []).append(candidate)

    dedup = {}
    for order_id, candidates in candidates_by_id.items():
        if len(candidates) > 1:
            exclusions["duplicate_excluded"] = exclusions.get("duplicate_excluded", 0) + len(candidates) - 1
        dedup[order_id] = max(candidates, key=lambda item: (item[0], item[1], item[2]))

    eligible = []
    for order_id, (received, source, record_key, raw, amount, order_date, state) in dedup.items():
        if order_date.year != as_of.year:
            exclude("outside_as_of_year")
            continue
        if order_date > as_of:
            exclude("after_as_of_date")
            continue
        if state not in jurisdictions:
            exclude("unknown_state")
            continue
        eligible.append({
            "order_id": order_id, "date": order_date, "state": state,
            "amount": amount, "facilitator": _flag(raw.get("marketplace_facilitator")),
            "promotional": _flag(raw.get("promotional")),
        })

    annual_days = int(rules.get("annual_days", 365))
    watch_ratio = _money(rules.get("status_watch_ratio", 0.9))
    observed_days = ((as_of - min((row["date"] for row in eligible), default=as_of)).days + 1) if eligible else 0
    totals = {state: {"cumulative": Decimal(0), "promo": Decimal(0), "nonpromo": Decimal(0), "facilitator_excluded": Decimal(0), "orders": 0}
              for state in jurisdictions}
    for row in eligible:
        policy = jurisdictions[row["state"]]
        qualifies = (not row["facilitator"]) or policy["facilitator_sales_count"]
        if not qualifies:
            totals[row["state"]]["facilitator_excluded"] += row["amount"]
            continue
        bucket = totals[row["state"]]
        bucket["cumulative"] += row["amount"]
        bucket["orders"] += 1
        if row["promotional"]:
            bucket["promo"] += row["amount"]
        else:
            bucket["nonpromo"] += row["amount"]

    state_summary = []
    alerts = []
    for state in sorted(jurisdictions):
        policy = jurisdictions[state]
        bucket = totals[state]
        projected = (bucket["nonpromo"] * Decimal(annual_days) / Decimal(observed_days)) if observed_days else Decimal(0)
        threshold = policy["threshold"]
        if projected >= threshold:
            status = "REGISTER"
        elif projected >= threshold * watch_ratio:
            status = "WATCH"
        else:
            status = "MONITOR"
        row = {
            "state": state,
            "name": policy["name"],
            "cumulative_qualifying": _rounded(bucket["cumulative"]),
            "promotional_qualifying": _rounded(bucket["promo"]),
            "non_promotional_qualifying": _rounded(bucket["nonpromo"]),
            "projected_annual": _rounded(projected),
            "threshold": _rounded(threshold),
            "status": status,
            "observed_days": observed_days,
            "qualifying_orders": bucket["orders"],
            "facilitator_excluded_amount": _rounded(bucket["facilitator_excluded"]),
        }
        state_summary.append(row)
        if status in {"REGISTER", "WATCH"}:
            alerts.append({"state": state, "status": status, "projected_annual": row["projected_annual"], "threshold": row["threshold"], "as_of_date": as_of.isoformat()})

    assumptions = {
        "as_of_date": as_of.isoformat(),
        "rounding": "Decimal ROUND_HALF_UP to cents",
        "promotional_treatment": "Promotional qualifying dollars remain cumulative but are excluded from forecast pace.",
        "observed_period": "Inclusive earliest eligible order date through as_of_date; projection uses annual_days.",
        "status_rules": {"watch_ratio": float(watch_ratio), "register": "projected_annual >= threshold", "watch": "projected_annual >= threshold * watch_ratio and below threshold"},
        "duplicate_rule": "Latest received_at wins; exact timestamp ties use lexicographically greatest source.",
        "exclusions": dict(sorted(exclusions.items())),
        "rules_source": rules.get("source", "supplied rules"),
        "prior_alerts_informational": True,
        "max_records": max_records,
    }
    return {"alerts": alerts, "state_summary": state_summary, "assumptions": assumptions}


if __name__ == "__main__":
    import argparse, csv, json
    parser = argparse.ArgumentParser(description="Run the Larkfield nexus monitor")
    parser.add_argument("orders_csv")
    parser.add_argument("rules_json")
    parser.add_argument("as_of_date")
    args = parser.parse_args()
    with open(args.orders_csv, newline="", encoding="utf-8") as handle:
        records = list(csv.DictReader(handle))
    with open(args.rules_json, encoding="utf-8") as handle:
        rules = json.load(handle)
    print(json.dumps(monitor(records, rules, args.as_of_date), indent=2, sort_keys=True))
