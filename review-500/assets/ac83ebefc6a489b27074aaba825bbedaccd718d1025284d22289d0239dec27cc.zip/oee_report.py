"""Deterministic Willowmere OEE report builder for Cells 1-12."""
from datetime import datetime, time
import json
import os
import sys
import math

# All operating assumptions live here so a future commissioning change is local.
CELL_CONFIG = {
    "CELL01": {"ideal_cycle_seconds": 12.0, "outputs_per_cycle": 1},
    "CELL02": {"ideal_cycle_seconds": 15.0, "outputs_per_cycle": 1},
    "CELL03": {"ideal_cycle_seconds": 10.0, "outputs_per_cycle": 1},
    "CELL04": {"ideal_cycle_seconds": 20.0, "outputs_per_cycle": 1},
    "CELL05": {"ideal_cycle_seconds": 18.0, "outputs_per_cycle": 1},
    "CELL06": {"ideal_cycle_seconds": 16.0, "outputs_per_cycle": 1},
    "CELL07": {"ideal_cycle_seconds": 24.0, "outputs_per_cycle": 2},
    "CELL08": {"ideal_cycle_seconds": 14.0, "outputs_per_cycle": 1},
    "CELL09": {"ideal_cycle_seconds": 22.0, "outputs_per_cycle": 1},
    "CELL10": {"ideal_cycle_seconds": 11.0, "outputs_per_cycle": 1},
    "CELL11": {"ideal_cycle_seconds": 19.0, "outputs_per_cycle": 1},
    "CELL12": {"ideal_cycle_seconds": 18.0, "outputs_per_cycle": 2},
}
SHIFT_ORDER = ("SHIFT1", "SHIFT2", "SHIFT3")
EXCLUDED_REASONS = frozenset(("PM", "NO_MATERIAL"))

def _timestamp(value, field):
    if not isinstance(value, str):
        raise ValueError(f"{field} must be an ISO-8601 timestamp string")
    try:
        parsed = datetime.fromisoformat(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field} is not a valid ISO-8601 timestamp") from exc
    if parsed.tzinfo is not None:
        raise ValueError(f"{field} must be timezone-naive")
    return parsed

def _shift(timestamp):
    clock = timestamp.time()
    if time(6, 0) <= clock < time(14, 0):
        return "SHIFT1"
    if time(14, 0) <= clock < time(21, 49):
        return "SHIFT2"
    return "SHIFT3"

def _metrics(run, downtime, good, reject, config):
    planned = run + downtime
    produced = good + reject
    theoretical = produced / config["outputs_per_cycle"] * config["ideal_cycle_seconds"] / 60.0
    availability = run / planned if planned > 0 else None
    performance = min(1.0, theoretical / run) if run > 0 else None
    quality = good / produced if produced > 0 else None
    oee = availability * performance * quality if None not in (availability, performance, quality) else None
    return {"run_minutes": run, "downtime_minutes": downtime,
            "planned_production_minutes": planned, "good_units": good,
            "reject_units": reject, "theoretical_production_minutes": theoretical,
            "availability": availability, "performance": performance,
            "quality": quality, "oee": oee}

def build_report(events, period_start, period_end):
    """Return a JSON-compatible report for events whose starts are in [start, end)."""
    if not isinstance(events, (list, tuple)):
        raise ValueError("events must be a list")
    start = _timestamp(period_start, "period_start")
    end = _timestamp(period_end, "period_end")
    if end <= start:
        raise ValueError("period_end must be after period_start")
    buckets = {cell: {shift: [0.0, 0.0, 0, 0] for shift in SHIFT_ORDER} for cell in CELL_CONFIG}
    # Validate every row before aggregation, including rows outside the requested period.
    parsed_events = []
    for index, event in enumerate(events):
        if not isinstance(event, dict):
            raise ValueError(f"event {index} must be an object")
        try:
            duration = float(event["duration_minutes"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"event {index} duration_minutes must be numeric") from exc
        if not math.isfinite(duration) or duration <= 0:
            raise ValueError(f"event {index} duration_minutes must be positive")
        stamp = _timestamp(event.get("timestamp"), f"event {index} timestamp")
        parsed_events.append((event, stamp, duration))
    for event, stamp, duration in parsed_events:
        cell = event.get("cell_id")
        if stamp < start or stamp >= end or cell not in buckets:
            continue
        shift = _shift(stamp)
        if event.get("state") == "RUN":
            bucket = buckets[cell][shift]
            bucket[0] += duration
            bucket[2] += int(event.get("good_units", 0) or 0)
            bucket[3] += int(event.get("reject_units", 0) or 0)
        elif event.get("state") == "DOWN" and event.get("downtime_reason") not in EXCLUDED_REASONS:
            buckets[cell][shift][1] += duration
    cells = []
    plant_raw = [0.0, 0.0, 0, 0]
    plant_theoretical = 0.0
    for cell, config in CELL_CONFIG.items():
        shifts = []
        cell_raw = [0.0, 0.0, 0, 0]
        for shift in SHIFT_ORDER:
            values = buckets[cell][shift]
            metrics = _metrics(*values, config)
            shifts.append({"shift_id": shift, **metrics})
            for i in range(4):
                cell_raw[i] += values[i]
        aggregate = _metrics(*cell_raw, config)
        cells.append({"cell_id": cell, "shifts": shifts, "aggregate": aggregate})
        for i in range(4):
            plant_raw[i] += cell_raw[i]
        plant_theoretical += aggregate["theoretical_production_minutes"]
    plant = _metrics(*plant_raw, {"ideal_cycle_seconds": 0.0, "outputs_per_cycle": 1})
    plant["theoretical_production_minutes"] = plant_theoretical
    plant["performance"] = min(1.0, plant_theoretical / plant_raw[0]) if plant_raw[0] > 0 else None
    plant["oee"] = (plant["availability"] * plant["performance"] * plant["quality"]
                    if None not in (plant["availability"], plant["performance"], plant["quality"]) else None)
    return {"period_start": period_start, "period_end": period_end, "cells": cells, "plant": plant}

def _main(argv):
    if len(argv) != 3:
        raise ValueError("usage: python oee_report.py INPUT.json OUTPUT.json")
    input_path, output_path = argv[1], argv[2]
    try:
        with open(input_path, "r", encoding="utf-8") as source:
            payload = json.load(source)
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read input JSON: {exc}") from exc
    if not isinstance(payload, dict) or not {"events", "period_start", "period_end"} <= payload.keys():
        raise ValueError("input JSON must contain events, period_start, and period_end")
    report = build_report(payload["events"], payload["period_start"], payload["period_end"])
    rendered = json.dumps(report, ensure_ascii=True, allow_nan=False, sort_keys=False, separators=(",", ":")) + "\n"
    temporary = output_path + ".tmp"
    try:
        with open(temporary, "w", encoding="utf-8", newline="\n") as destination:
            destination.write(rendered)
        os.replace(temporary, output_path)
    except OSError as exc:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise ValueError(f"cannot write output JSON: {exc}") from exc

if __name__ == "__main__":
    try:
        _main(sys.argv)
    except ValueError as exc:
        print(f"oee_report.py: error: {exc}", file=sys.stderr)
        raise SystemExit(2)
