# Willowmere OEE logic reconstruction

## Observed legacy behavior

The executable baseline selects rows by event start in the half-open interval `[period_start, period_end)`. It emits `CELL01` through `CELL11`, each with `SHIFT1`, `SHIFT2`, and `SHIFT3` in that order. First shift begins at 06:00, second at 14:00, and third at the MES release marker 21:49.

Two downtime codes are removed from both downtime and planned-production minutes: `PM` and `NO_MATERIAL`. Ordinary codes and a missing (`null`) reason remain included. This is a reporting convention, not a claim that the equipment was running. The supplied operational evidence supports the explanation: PM occurs outside the OEE loading window, while material starvation is owned by upstream supply rather than the cell.

The 21:49 boundary is eleven minutes before the nominal 22:00 physical handover. Evidence says the controlled transfer starts at 22:00 but leadership reporting follows the MES release marker, so the observed attribution is retained for comparability. An event exactly at 21:49 is third shift; one second earlier remains second shift.

CELL07 uses a paired-output branch. Its twin-spindle Ironvale machine releases two bearings per completed machine cycle; theoretical production time therefore uses produced units divided by two before applying the ideal cycle. Treating each bearing as a separate cycle would overstate theoretical time and depress or distort performance.

## Cell 12 recommendation

Commissioning evidence identifies CELL12 as the same twin-spindle equipment family with the same paired discharge arrangement. I recommend the paired-output treatment and the stated 18-second ideal cycle per completed paired-output cycle. The alternative, a normal single-output cell, is simpler but would count two bearings as two cycles and inflate theoretical production time by 2x, making performance and OEE appear worse than the equipment's completed-cycle behavior. The implementation therefore adds CELL12 after CELL11 with `outputs_per_cycle=2` and `ideal_cycle_seconds=18.0`.

This is an evidence-supported recommendation, while the exact commercial machine configuration remains an operational assumption that should be revisited if commissioning changes the discharge mode.

## Usage and maintenance

Import `oee_report.py` and call `build_report(events, period_start, period_end)`. Events are mappings with `event_id`, `cell_id`, ISO-8601 timezone-naive `timestamp`, positive numeric `duration_minutes`, `state` (`RUN` or `DOWN`), nonnegative `good_units` and `reject_units`, and a string or null `downtime_reason`. The function returns a JSON-compatible mapping with period fields, ordered cells, ordered shifts, and plant aggregate.

Run the offline command-line feed as:

```bash
python oee_report.py INPUT.json OUTPUT.json
```

`INPUT.json` contains `events`, `period_start`, and `period_end`; output is canonical, stable-order JSON. Invalid JSON, timestamps, periods, schema, or any zero/negative duration produces a diagnostic on stderr and exit status 2 without replacing a prior output with a report. Inputs are not mutated, and repeated runs are byte-identical.

Shift boundaries, excluded reasons, and all equipment parameters are centralized at the top of the module. To reproduce, use Python 3.11 with only the standard library, place the two files in one directory, and run the command above; no network access is needed.

Limitations: timestamps are timezone-naive local plant time, and daylight-saving transitions are outside this feed's contract. Events from unknown cells are ignored after validation, matching the legacy aggregation scope. Performance is capped at 1.0 and metrics with zero denominators are `null`.
