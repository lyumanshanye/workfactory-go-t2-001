# Revenue reconciliation package

## Rerun

Use Python 3.11 with `openpyxl` installed and network access disabled. From the unpacked package directory:

```bash
python -c "from reconcile import analyze; import json; print(json.dumps(analyze('/path/to/franchise_recon_source.xlsx', '2025-Q1', 60), indent=2))"
```

The command-line equivalent is:

```bash
python reconcile.py /path/to/franchise_recon_source.xlsx 2025-Q1 60
```

`analyze(source_path, quarter, sample_size=60)` filters `Daily_Recon` to the requested quarter, ranks distinct locations by the ascending SHA-256 digest of `quarter|location_id` (UTF-8), and returns the selected locations alphabetically. The workbook's field definitions describe the signed adjustment columns.

## Method and assumptions

- Adjusted deposits are `bank_deposit + card_timing_adjustment + tip_pass_through_adjustment`; both adjustments are signed.
- Each row's residual is POS revenue minus adjusted deposits. Absolute residuals up to and including $0.02 are classified as rounding and suppressed before any aggregation.
- The signed sampled unexplained variance is divided by sampled POS revenue. That rate is multiplied by all requested-quarter POS revenue for the projection. Rates use half-up rounding to six decimals and monetary outputs to two decimals.
- `ESCALATE` applies when the absolute unrounded rate is at least 0.005; otherwise the result is `NO_ESCALATION`.
- The source is expected to have a `Daily_Recon` sheet with the fields named in the included field definitions. The implementation accepts up to 100,000 data rows and rejects larger workbooks and invalid sample or quarter requests.

## Bounded judgement and limitations

This deterministic sample is suitable for a reproducible committee workpaper and for deciding whether renewal notices should receive additional attention under the stated 0.5% policy threshold. It is not a statistical random sample, has no calculated confidence interval, and does not establish that unsampled locations behave like sampled locations. The ratio projection is therefore an estimate for triage, not a substitute for a full-population reconciliation. Conclusions also depend on the completeness and correct classification of the source workbook's signed timing and tip fields; investigate material exceptions before treating the decision as assurance over all 240 locations.
