"""Deterministic sampled POS-to-bank reconciliation for Wexmoor Manufacturing."""

from __future__ import annotations

import hashlib
import json
import sys
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any

from openpyxl import load_workbook


MAX_DATA_ROWS = 100_000
ROUNDING_THRESHOLD = Decimal("0.02")
ESCALATION_THRESHOLD = Decimal("0.005")
MONEY_QUANTUM = Decimal("0.01")
RATE_QUANTUM = Decimal("0.000001")
TOP_LEVEL_KEYS = (
    "quarter", "sample_size", "selected_locations", "sample_pos_revenue", "sample_bank_deposits",
    "card_timing_adjustments", "tip_pass_through_adjustments", "sample_adjusted_deposits",
    "rounding_excluded", "unexplained_variance", "variance_rate", "population_pos_revenue",
    "projected_unexplained_variance", "decision", "locations", "method_note",
)


def _money(value: Decimal | int | float | str) -> Decimal:
    return Decimal(str(value)).quantize(MONEY_QUANTUM, rounding=ROUND_HALF_UP)


def _rate(value: Decimal) -> Decimal:
    return value.quantize(RATE_QUANTUM, rounding=ROUND_HALF_UP)


def _json_money(value: Decimal) -> float:
    return float(_money(value))


def _headers(ws):
    for row_number, row in enumerate(ws.iter_rows(min_row=1, max_row=min(ws.max_row, 20), values_only=True), start=1):
        values = [str(value).strip() if value is not None else "" for value in row]
        required = {"location_id", "quarter", "pos_revenue", "bank_deposit", "card_timing_adjustment", "tip_pass_through_adjustment"}
        if required.issubset(values):
            return row_number, {name: values.index(name) for name in required}
    raise ValueError("Daily_Recon headers not found")


def analyze(source_path: str | Path, quarter: str, sample_size: int = 60) -> dict[str, Any]:
    """Analyze a deterministic location sample for one quarter."""
    if not isinstance(sample_size, int) or isinstance(sample_size, bool):
        raise ValueError("sample_size must be an integer")
    if sample_size < 1:
        raise ValueError("sample_size must be at least 1")

    workbook = load_workbook(source_path, read_only=True, data_only=True)
    if "Daily_Recon" not in workbook.sheetnames:
        raise ValueError("Daily_Recon sheet not found")
    worksheet = workbook["Daily_Recon"]
    header_row, headers = _headers(worksheet)
    rows = []
    quarter_rows = []
    row_count = 0
    for row in worksheet.iter_rows(min_row=header_row + 1, values_only=True):
        values = [row[index] for index in headers.values()]
        if all(value is None for value in values):
            continue
        row_count += 1
        if row_count > MAX_DATA_ROWS:
            raise ValueError("Daily_Recon exceeds 100,000 data rows")
        record = {
            "location_id": str(row[headers["location_id"]]).strip(),
            "quarter": str(row[headers["quarter"]]).strip(),
            "pos_revenue": _money(row[headers["pos_revenue"]]),
            "bank_deposit": _money(row[headers["bank_deposit"]]),
            "card_timing_adjustment": _money(row[headers["card_timing_adjustment"]]),
            "tip_pass_through_adjustment": _money(row[headers["tip_pass_through_adjustment"]]),
        }
        rows.append(record)
        if record["quarter"] == quarter:
            quarter_rows.append(record)
    workbook.close()

    if not quarter_rows:
        raise ValueError(f"quarter not found: {quarter}")
    locations = sorted({record["location_id"] for record in quarter_rows})
    if sample_size > len(locations):
        raise ValueError("sample_size exceeds distinct locations in requested quarter")
    ranked = sorted(locations, key=lambda location: (hashlib.sha256(f"{quarter}|{location}".encode("utf-8")).hexdigest(), location))
    selected = sorted(ranked[:sample_size])
    selected_set = set(selected)

    by_location: dict[str, dict[str, Decimal]] = defaultdict(lambda: {
        "pos_revenue": Decimal("0"), "bank_deposits": Decimal("0"),
        "card_timing_adjustments": Decimal("0"), "tip_pass_through_adjustments": Decimal("0"),
        "adjusted_deposits": Decimal("0"), "rounding_excluded": Decimal("0"), "unexplained_variance": Decimal("0"),
    })
    population_pos = Decimal("0")
    for record in quarter_rows:
        population_pos += record["pos_revenue"]
        if record["location_id"] not in selected_set:
            continue
        aggregate = by_location[record["location_id"]]
        adjusted = record["bank_deposit"] + record["card_timing_adjustment"] + record["tip_pass_through_adjustment"]
        residual = record["pos_revenue"] - adjusted
        aggregate["pos_revenue"] += record["pos_revenue"]
        aggregate["bank_deposits"] += record["bank_deposit"]
        aggregate["card_timing_adjustments"] += record["card_timing_adjustment"]
        aggregate["tip_pass_through_adjustments"] += record["tip_pass_through_adjustment"]
        aggregate["adjusted_deposits"] += adjusted
        if abs(residual) <= ROUNDING_THRESHOLD:
            aggregate["rounding_excluded"] += residual
        else:
            aggregate["unexplained_variance"] += residual

    sample_pos = sum((by_location[location]["pos_revenue"] for location in selected), Decimal("0"))
    if sample_pos <= 0:
        raise ValueError("sample POS revenue must be positive")
    sample_bank = sum((by_location[location]["bank_deposits"] for location in selected), Decimal("0"))
    card_total = sum((by_location[location]["card_timing_adjustments"] for location in selected), Decimal("0"))
    tip_total = sum((by_location[location]["tip_pass_through_adjustments"] for location in selected), Decimal("0"))
    adjusted_total = sum((by_location[location]["adjusted_deposits"] for location in selected), Decimal("0"))
    rounding_total = sum((by_location[location]["rounding_excluded"] for location in selected), Decimal("0"))
    unexplained_total = sum((by_location[location]["unexplained_variance"] for location in selected), Decimal("0"))
    rate_raw = unexplained_total / sample_pos
    projected_raw = rate_raw * population_pos
    result = {
        "quarter": quarter,
        "sample_size": sample_size,
        "selected_locations": selected,
        "sample_pos_revenue": _json_money(sample_pos),
        "sample_bank_deposits": _json_money(sample_bank),
        "card_timing_adjustments": _json_money(card_total),
        "tip_pass_through_adjustments": _json_money(tip_total),
        "sample_adjusted_deposits": _json_money(adjusted_total),
        "rounding_excluded": _json_money(rounding_total),
        "unexplained_variance": _json_money(unexplained_total),
        "variance_rate": float(_rate(rate_raw)),
        "population_pos_revenue": _json_money(population_pos),
        "projected_unexplained_variance": _json_money(projected_raw),
        "decision": "ESCALATE" if abs(rate_raw) >= ESCALATION_THRESHOLD else "NO_ESCALATION",
        "locations": [],
        "method_note": (
            "Deterministic SHA-256 location sample with row-level +/-$0.02 rounding suppression; "
            "signed unexplained variance is ratio-projected to quarter POS revenue. This is a reproducible "
            "sample and bounded estimate, not a full-population reconciliation or statistical confidence interval."
        ),
    }
    for location in selected:
        aggregate = by_location[location]
        result["locations"].append({
            "location_id": location,
            "pos_revenue": _json_money(aggregate["pos_revenue"]),
            "adjusted_deposits": _json_money(aggregate["adjusted_deposits"]),
            "rounding_excluded": _json_money(aggregate["rounding_excluded"]),
            "unexplained_variance": _json_money(aggregate["unexplained_variance"]),
        })
    assert tuple(result) == TOP_LEVEL_KEYS
    return result


def _main(argv: list[str]) -> int:
    if len(argv) not in (3, 4):
        print("Usage: python reconcile.py SOURCE.xlsx QUARTER [SAMPLE_SIZE]", file=sys.stderr)
        return 2
    result = analyze(argv[1], argv[2], int(argv[3]) if len(argv) == 4 else 60)
    print(json.dumps(result, indent=2, sort_keys=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv))
