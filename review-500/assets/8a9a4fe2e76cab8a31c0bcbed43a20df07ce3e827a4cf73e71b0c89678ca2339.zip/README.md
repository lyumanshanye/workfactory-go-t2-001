# Windermere dual-legacy COA model

`coa_model.py` exposes `analyze(records, period_a, period_b)` and uses only the Python 3.11 standard library. It commits to `ENTITY-NATURAL-PRODUCT-CONTROL`, retaining product on revenue/cost accounts and using `GEN` for balance-sheet accounts. Irish and Polish statutory rollups are carried as separate attributes; SOX class and constraint traces remain visible on every target and mapping row. The frozen Polish subsidiary identifier `9998` is preserved as supplied.

Sourced requirements are the segment vocabulary, statutory codes, SOX classes, product-margin rule, frozen-ledger rule, constraint IDs, and inclusive EUR1,000/10.0% materiality policy in `reporting_constraints.pdf`. Implementation assumptions are that the supplied account populations are authoritative, labels are descriptive only, and source product codes are retained in mapping rows.

Records are normalized for case and surrounding whitespace, validated completely before period filtering, and exact normalized duplicate row IDs are counted once. Contradictory duplicates, malformed fields, unmapped accounts, unknown products, and invalid periods raise categorized `ValueError`s. A valid population with no included records in either requested period returns a distinct `empty` result. `POSTED` and `SUSPENSE` are included; `VOID` and `TEST` are excluded.

Maintainers change `ACCOUNT_MAP` for crosswalks, `NATURAL`/`PRODUCTS` for segment definitions, and the `material` expression in `analyze` for policy thresholds; each is a single logical location. Outputs are factual and do not recommend entries, controls, or management action.
