"""Windermere dual-legacy chart-of-accounts analytical model."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import re

FIELDS = ("row_id","legacy_system","entity_code","legacy_account","legacy_label","jurisdiction","product_code","period","amount_eur","record_status")
NATURAL = {
    "1000": ("Cash", "IE-CASH", "PL-100", "C01"),
    "1200": ("Trade receivables", "IE-AR", "PL-120", "C01"),
    "2100": ("Trade payables", "IE-AP", "PL-200", "C01"),
    "4000": ("Revenue", "IE-REV", "PL-700", "C02"),
    "5000": ("Cost of sales", "IE-COGS", "PL-730", "C03"),
    "6100": ("Operating expense", "IE-OPEX", "PL-550", "C04"),
}
PRODUCTS = {"P1":"Fabrication", "P2":"Components", "GEN":"Shared/overhead"}
ACCOUNT_MAP = {
    ("IE_GL","IE01","1000"):"1000", ("IE_GL","IE01","1200"):"1200", ("IE_GL","IE01","2100"):"2100",
    ("IE_GL","IE01","4000"):"4000", ("IE_GL","IE01","5000"):"5000", ("IE_GL","IE01","6100"):"6100",
    ("PL_FK","PL01","7001"):"4000", ("PL_FK","PL01","7300"):"5000", ("PL_FK","PL01","5500"):"6100",
    ("PL_FK","PL01","1300"):"1200", ("PL_FK","PL01","2001"):"2100", ("PL_FK","PL01","9998"):"1000",
}
LOCKED = {("PL_FK","PL01","9998")}
INCLUDED = {"POSTED","SUSPENSE"}; EXCLUDED = {"VOID","TEST"}
MONEY_Q = Decimal("0.01"); PCT_Q = Decimal("0.1")

def _norm(v):
    return str(v).strip().upper() if v is not None else ""

def _money(v):
    try:
        return Decimal(str(v).strip())
    except (InvalidOperation, ValueError, AttributeError):
        raise ValueError("INVALID_RECORD amount")

def _period(v):
    s = _norm(v)
    if not re.fullmatch(r"\d{4}-Q[1-4]", s): raise ValueError("INVALID_PERIOD")
    return s

def _q(v, quantum):
    return v.quantize(quantum, rounding=ROUND_HALF_UP)

def analyze(records, period_a, period_b):
    pa, pb = _period(period_a), _period(period_b)
    if pa == pb: raise ValueError("INVALID_PERIOD")
    if not isinstance(records, list): raise ValueError("INVALID_RECORD records")
    seen = {}; clean=[]
    for raw in records:
        if not isinstance(raw, dict) or any(f not in raw for f in FIELDS):
            raise ValueError("INVALID_RECORD")
        n = {"row_id":_norm(raw["row_id"]), "legacy_system":_norm(raw["legacy_system"]), "entity_code":_norm(raw["entity_code"]),
             "legacy_account":_norm(raw["legacy_account"]), "legacy_label":_norm(raw["legacy_label"]), "jurisdiction":_norm(raw["jurisdiction"]),
             "product_code":_norm(raw["product_code"]), "period":_norm(raw["period"]), "record_status":_norm(raw["record_status"])}
        if not n["row_id"] or n["legacy_system"] not in {"IE_GL","PL_FK"} or n["entity_code"] not in {"IE01","PL01"} or not n["legacy_account"] or not n["legacy_label"] or n["jurisdiction"] not in {"IE","PL"} or not n["period"] or n["record_status"] not in INCLUDED|EXCLUDED:
            raise ValueError("INVALID_RECORD")
        try: n["period"] = _period(n["period"])
        except ValueError: raise ValueError("INVALID_RECORD")
        n["amount"] = _money(raw["amount_eur"])
        key=(n["legacy_system"],n["entity_code"],n["legacy_account"])
        if key not in ACCOUNT_MAP: raise ValueError(f"UNMAPPED_ACCOUNT {n['legacy_account']}")
        if n["product_code"] not in PRODUCTS: raise ValueError(f"UNKNOWN_PRODUCT {n['product_code']}")
        # jurisdiction/entity consistency is an impossible field value
        if (n["entity_code"]=="IE01" and n["jurisdiction"]!="IE") or (n["entity_code"]=="PL01" and n["jurisdiction"]!="PL"):
            raise ValueError("INVALID_RECORD")
        signature=tuple(n[k] for k in ("legacy_system","entity_code","legacy_account","jurisdiction","product_code","period","record_status"))+ (n["amount"],)
        if n["row_id"] in seen:
            if seen[n["row_id"]] != signature: raise ValueError(f"CONFLICTING_DUPLICATE {n['row_id']}")
            continue
        seen[n["row_id"]]=signature; clean.append(n)
    included=[r for r in clean if r["record_status"] in INCLUDED]
    relevant=[r for r in included if r["period"] in {pa,pb}]
    if not relevant:
        return {"status":"empty","periods":{"period_a":pa,"period_b":pb},"target_accounts":[],"legacy_mapping":[],"variances":[],"controls":{"period_a":{"included_input_total_eur":Decimal("0.00"),"mapped_output_total_eur":Decimal("0.00")},"period_b":{"included_input_total_eur":Decimal("0.00"),"mapped_output_total_eur":Decimal("0.00")}}}
    targets={}; mappings={}; var={}; drivers={}
    for r in relevant:
        nat=NATURAL[ACCOUNT_MAP[(r["legacy_system"],r["entity_code"],r["legacy_account"])]][0] and ACCOUNT_MAP[(r["legacy_system"],r["entity_code"],r["legacy_account"])]
        prod = r["product_code"] if nat in {"4000","5000"} else "GEN"
        control=NATURAL[nat][3]; target=f"{r['entity_code']}-{nat}-{prod}-{control}"
        cons=["CT-SEG", "CT-IE" if r["entity_code"]=="IE01" else "CT-PL", "CT-SOX"]
        if nat in {"4000","5000"}: cons.append("CT-MARGIN")
        if (r["legacy_system"],r["entity_code"],r["legacy_account"]) in LOCKED: cons.append("CT-FROZEN")
        targets[target]={"target_account":target,"target_label":NATURAL[nat][0],"natural_code":nat,"product_code":prod,"control_class":control,"ie_stat_code":NATURAL[nat][1],"pl_stat_code":NATURAL[nat][2],"constraint_ids":sorted(set(cons))}
        mkey=(r["legacy_system"],r["entity_code"],r["legacy_account"],r["product_code"])
        mappings[mkey]={"legacy_system":r["legacy_system"],"entity_code":r["entity_code"],"legacy_account":r["legacy_account"],"product_code":r["product_code"],"target_account":target,"constraint_ids":sorted(set(cons))}
        vk=target; var.setdefault(vk,{pa:Decimal(0),pb:Decimal(0)})[r["period"]]+=r["amount"]
        sk=(target,r["legacy_system"],r["legacy_account"]); drivers.setdefault(sk,{pa:Decimal(0),pb:Decimal(0)})[r["period"]]+=r["amount"]
    variances=[]
    for target in sorted(var):
        a,b=var[target].get(pa,Decimal(0)),var[target].get(pb,Decimal(0)); ch=b-a
        pct=None if a==0 else _q(ch/abs(a)*Decimal(100),PCT_Q)
        material=abs(ch)>=Decimal(1000) or (a!=0 and abs(ch/abs(a)*Decimal(100))>=Decimal('10.0'))
        ds=[]
        if material:
            cand=[]
            for (t,sys,acct),vv in drivers.items():
                if t==target: cand.append((vv.get(pb,Decimal(0))-vv.get(pa,Decimal(0)),sys,acct))
            cand.sort(key=lambda x:(-abs(x[0]),x[1],x[2]))
            ds=[{"legacy_system":s,"legacy_account":ac,"change_eur":_q(c,MONEY_Q)} for c,s,ac in cand[:3]]
        variances.append({"target_account":target,"period_a_amount_eur":_q(a,MONEY_Q),"period_b_amount_eur":_q(b,MONEY_Q),"change_eur":_q(ch,MONEY_Q),"change_pct":pct,"material":material,"drivers":ds})
    controls={}
    for p in (pa,pb):
        total=sum((r["amount"] for r in included if r["period"]==p),Decimal(0)); controls["period_a" if p==pa else "period_b"]={"included_input_total_eur":_q(total,MONEY_Q),"mapped_output_total_eur":_q(total,MONEY_Q)}
    return {"status":"ok","periods":{"period_a":pa,"period_b":pb},"target_accounts":[targets[k] for k in sorted(targets)],"legacy_mapping":[mappings[k] for k in sorted(mappings)],"variances":variances,"controls":controls}
