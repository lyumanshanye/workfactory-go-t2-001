# Cross-Holding Obligor Memo

This package is an offline Python 3.11 model for Merrowdale Public Finance's annual credit refresh.

## Contract

Import `build_memo(source, as_of, materiality_pct=0.10)` from `cross_holding_obligor_memo.py`. `source` is the parsed object from `certificate_holdings.json`; `as_of` is a real `YYYY-MM-DD` date string; and `materiality_pct` is in `(0, 1]`. The return value is JSON serializable and contains `as_of`, portfolio totals (`total_prior_exposure`, `total_current_exposure`, `total_change`), `obligors`, `material_changes`, `concentration`, and `recommendation`.

Each obligor is grouped by case-folded disclosure text with surrounding and repeated whitespace normalized. Its issuer-level `evidence` rows retain certificate ID, issuer, state, both source texts, and a `linkage_confirmed` flag. A linkage is confirmed only when the normalized disclosure is a substring of that record's normalized appropriation text; issuer names or generic wording do not establish a link.

## Rules and validation

Prior/current exposures must be finite, non-negative numbers. The source must contain a non-empty `certificates` list with unique IDs and all required string fields. Invalid shape, missing fields, duplicate IDs, wrong text types, negative/non-finite exposures, invalid dates, blank disclosures, or an out-of-range materiality value raise `ValueError`.

Group change is current minus prior. It is material when `abs(change) >= materiality_pct * prior`; for zero prior, any non-zero current amount is material. Current share is current group exposure divided by total current exposure, or zero for every group when the total is zero. Lists are sorted by normalized operator and certificate ID. The concentration is the largest confirmed group (ties use operator name ascending). A share of at least `0.30` produces `heightened committee review`; otherwise the recommendation is `routine monitoring`.

These results are screening evidence from the supplied certificate language only. They do not perform external legal, operational, or credit research, and the recommendation remains subject to committee judgment.

## Offline reproduction

From the directory containing the source file:

```bash
python3 -c 'import json, cross_holding_obligor_memo as m; s=json.load(open("../references/certificate_holdings.json")); print(json.dumps(m.build_memo(s, "2026-06-30"), indent=2, sort_keys=True))'
```

The module has no third-party imports, network calls, clock reads, or randomness. It can also be run as a CLI: `python3 cross_holding_obligor_memo.py ../references/certificate_holdings.json 2026-06-30`.
