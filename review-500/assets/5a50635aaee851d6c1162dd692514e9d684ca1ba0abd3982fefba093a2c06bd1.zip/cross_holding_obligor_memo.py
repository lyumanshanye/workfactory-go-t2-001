"""Deterministic cross-holding obligor exposure memo model."""
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import math
import re
from typing import Any

REQUIRED_FIELDS = (
    "certificate_id", "issuer", "state", "prior_exposure", "current_exposure",
    "appropriation_text", "operator_disclosure"
)
CONCENTRATION_THRESHOLD = Decimal("0.30")
_NUMERIC_QUANT = Decimal("0.00000001")


def _normalize_text(value: str) -> str:
    return " ".join(value.casefold().split())


def _decimal(value: Any, field: str) -> Decimal:
    if isinstance(value, bool):
        raise ValueError(f"{field} must be numeric")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError(f"{field} must be numeric") from None
    if not result.is_finite() or result < 0:
        raise ValueError(f"{field} must be finite and non-negative")
    return result


def _number(value: Decimal) -> int | float:
    value = value.quantize(_NUMERIC_QUANT, rounding=ROUND_HALF_UP)
    if value == value.to_integral_value():
        return int(value)
    return float(value)


def _validate(source: Any, as_of: Any, materiality_pct: Any) -> list[dict[str, Any]]:
    if not isinstance(source, dict) or not isinstance(source.get("certificates"), list):
        raise ValueError("source must be an object with a certificates list")
    certificates = source["certificates"]
    if not certificates:
        raise ValueError("certificates must not be empty")
    if not isinstance(as_of, str):
        raise ValueError("as_of must be an ISO date string")
    try:
        date.fromisoformat(as_of)
    except (TypeError, ValueError):
        raise ValueError("as_of must be a real ISO YYYY-MM-DD date") from None
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", as_of):
        raise ValueError("as_of must use YYYY-MM-DD")
    pct = _decimal(materiality_pct, "materiality_pct")
    if pct <= 0 or pct > 1:
        raise ValueError("materiality_pct must be in (0, 1]")
    seen: set[Any] = set()
    rows: list[dict[str, Any]] = []
    for cert in certificates:
        if not isinstance(cert, dict):
            raise ValueError("each certificate must be an object")
        missing = [field for field in REQUIRED_FIELDS if field not in cert]
        if missing:
            raise ValueError(f"missing required fields: {', '.join(missing)}")
        cid = cert["certificate_id"]
        if not isinstance(cid, str) or not cid:
            raise ValueError("certificate_id must be a non-empty string")
        if cid in seen:
            raise ValueError(f"duplicate certificate_id: {cid}")
        seen.add(cid)
        for field in ("issuer", "state", "appropriation_text", "operator_disclosure"):
            if not isinstance(cert[field], str):
                raise ValueError(f"{field} must be a string")
        prior = _decimal(cert["prior_exposure"], "prior_exposure")
        current = _decimal(cert["current_exposure"], "current_exposure")
        disclosure_norm = _normalize_text(cert["operator_disclosure"])
        appropriation_norm = _normalize_text(cert["appropriation_text"])
        if not disclosure_norm:
            raise ValueError("operator_disclosure must not be blank")
        rows.append({**cert, "_prior": prior, "_current": current,
                     "_operator": disclosure_norm,
                     "_confirmed": disclosure_norm in appropriation_norm})
    return rows, pct


def build_memo(source, as_of, materiality_pct=0.10):
    """Build a JSON-serializable exposure memo from parsed certificate holdings."""
    rows, pct = _validate(source, as_of, materiality_pct)
    total_prior = sum((r["_prior"] for r in rows), Decimal(0))
    total_current = sum((r["_current"] for r in rows), Decimal(0))
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(row["_operator"], []).append(row)
    obligors = []
    for operator in sorted(groups):
        members = sorted(groups[operator], key=lambda r: r["certificate_id"])
        prior = sum((r["_prior"] for r in members), Decimal(0))
        current = sum((r["_current"] for r in members), Decimal(0))
        change = current - prior
        share = (current / total_current) if total_current else Decimal(0)
        material = (abs(change) >= pct * prior) if prior > 0 else (current != 0)
        evidence = [{
            "certificate_id": r["certificate_id"], "issuer": r["issuer"],
            "state": r["state"], "appropriation_text": r["appropriation_text"],
            "operator_disclosure": r["operator_disclosure"],
            "linkage_confirmed": r["_confirmed"]
        } for r in members]
        obligors.append({
            "operator": operator,
            "prior_exposure": _number(prior),
            "current_exposure": _number(current),
            "change": _number(change),
            "current_share": _number(share),
            "certificate_count": len(members),
            "certificate_ids": [r["certificate_id"] for r in members],
            "confirmed_linkage": all(r["_confirmed"] for r in members),
            "evidence": evidence,
            "material": material,
            "_share_decimal": share
        })
    confirmed = [o for o in obligors if o["confirmed_linkage"]]
    if confirmed:
        # Resolve equal shares by normalized operator name ascending.
        top_share = max(o["_share_decimal"] for o in confirmed)
        largest = sorted((o for o in confirmed if o["_share_decimal"] == top_share), key=lambda o: o["operator"])[0]
        concentration = {"operator": largest["operator"], "current_exposure": largest["current_exposure"], "current_share": largest["current_share"]}
        recommendation = "heightened committee review" if top_share >= CONCENTRATION_THRESHOLD else "routine monitoring"
    else:
        concentration = None
        recommendation = "routine monitoring"
    for obligor in obligors:
        del obligor["_share_decimal"]
    material_changes = [o for o in obligors if o["material"]]
    return {
        "as_of": as_of,
        "total_prior_exposure": _number(total_prior),
        "total_current_exposure": _number(total_current),
        "total_change": _number(total_current - total_prior),
        "obligors": obligors,
        "material_changes": material_changes,
        "concentration": concentration,
        "recommendation": recommendation,
    }


if __name__ == "__main__":
    import argparse, json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("as_of")
    parser.add_argument("--materiality-pct", type=float, default=0.10)
    args = parser.parse_args()
    with open(args.source, encoding="utf-8") as handle:
        payload = json.load(handle)
    print(json.dumps(build_memo(payload, args.as_of, args.materiality_pct), indent=2, sort_keys=True))
