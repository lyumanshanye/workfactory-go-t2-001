# Fallowbrook regional reconciliation

`reconciliation.py` is a Python 3.11, standard-library-only module for an offline comparison of the retiring SAS extract and the replacement pipeline extract. It has no installation step and does not use the network or the clock.

## Call contract

```python
reconcile(old_rows, new_rows, sample_size=100, seed="fallowbrook-2024")
```

Each argument is a list of mappings with `region`, `quarter`, `measure`, and `value`. The first three fields form the business key and must be nonblank strings. Values may be integers, floats, numeric strings, or blank/whitespace-only (blank means unavailable, not zero). Duplicate keys, malformed keys or values, a nonpositive/non-integer `sample_size`, and a non-string `seed` raise `ValueError`.

The return value contains `summary`, `selected_keys`, and `comparisons`. Every selected comparison preserves unavailable sides as JSON `null`. Rows are sorted lexically by region, quarter, and measure. The population includes keys with a usable value in either source; keys blank in both sources are excluded.

For comparable rows, `absolute_variance` is `new_value - old_value`; `relative_variance` divides it by `abs(old_value)` (or is `null` for a zero old value). A row is `within_tolerance` when `abs(absolute_variance) <= max(0.01, 1e-8 * abs(old_value))`; otherwise it is `genuine_divergence`. One-sided rows are `missing_old` or `missing_new`.

Sampling ranks the complete key with a SHA-256 digest of the seed and key, so the same inputs, seed, and sample size always produce identical JSON regardless of input row order. An oversized sample selects the whole eligible population. Two empty input lists return an empty, zero-count report.

## Offline reproduction

From the directory containing the two supplied CSV files and this module:

```python
import csv, json
from reconciliation import reconcile

def load(path):
    with open(path, newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))

old_rows = load("old_sas_output.csv")
new_rows = load("new_pipeline_output.csv")
first = reconcile(old_rows, new_rows, sample_size=100, seed="fallowbrook-2024")
second = reconcile(old_rows, new_rows, sample_size=100, seed="fallowbrook-2024")
assert json.dumps(first, sort_keys=True) == json.dumps(second, sort_keys=True)
print(json.dumps(first, indent=2, sort_keys=True))
```

The supplied extracts are evidence for exercising the package, not a production release decision. Sampling is deterministic selection for reproducibility, not a claim of statistical representativeness.
