"""Offline reconciliation for regional statistical extracts."""

from collections.abc import Mapping
import hashlib
import math


# Maintainer-facing policy boundary: change these values to revise the report policy.
ABSOLUTE_TOLERANCE = 0.01
RELATIVE_TOLERANCE = 1e-8
KEY_FIELDS = ("region", "quarter", "measure")


def _parse_value(value):
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError("value must be numeric or blank")
    if isinstance(value, str):
        if not value.strip():
            return None
        text = value.strip()
    elif isinstance(value, (int, float)):
        text = value
    else:
        raise ValueError("value must be numeric or blank")
    try:
        number = float(text)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("value must be numeric or blank") from exc
    if not math.isfinite(number):
        raise ValueError("value must be finite")
    return number


def _parse_source(rows, source_name):
    if not isinstance(rows, list):
        raise ValueError(f"{source_name} must be a list of mappings")
    parsed = {}
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            raise ValueError(f"{source_name}[{index}] must be a mapping")
        key_parts = []
        for field in KEY_FIELDS:
            if field not in row or not isinstance(row[field], str) or not row[field].strip():
                raise ValueError(f"{source_name}[{index}] has an invalid {field}")
            key_parts.append(row[field].strip())
        key = tuple(key_parts)
        if key in parsed:
            raise ValueError(f"duplicate business key in {source_name}: {key!r}")
        parsed[key] = _parse_value(row.get("value"))
    return parsed


def _empty_result():
    return {
        "summary": {
            "population_count": 0,
            "sampled_count": 0,
            "comparable_count": 0,
            "missing_old_count": 0,
            "missing_new_count": 0,
            "within_tolerance_count": 0,
            "genuine_divergence_count": 0,
            "max_absolute_variance": None,
        },
        "selected_keys": [],
        "comparisons": [],
    }


def reconcile(old_rows, new_rows, sample_size=100, seed="fallowbrook-2024"):
    """Compare two regional extracts and return a deterministic JSON-ready report."""
    if isinstance(sample_size, bool) or not isinstance(sample_size, int) or sample_size <= 0:
        raise ValueError("sample_size must be a positive integer")
    if not isinstance(seed, str):
        raise ValueError("seed must be a string")

    old = _parse_source(old_rows, "old_rows")
    new = _parse_source(new_rows, "new_rows")
    population = sorted(
        key for key in set(old) | set(new) if old.get(key) is not None or new.get(key) is not None
    )
    if not population:
        return _empty_result()

    def selection_token(key):
        payload = seed + "\x1f" + "\x1f".join(key)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    ranked = sorted(population, key=lambda key: (selection_token(key), key))
    selected = sorted(ranked[: min(sample_size, len(ranked))])
    comparisons = []
    for region, quarter, measure in selected:
        old_value = old.get((region, quarter, measure))
        new_value = new.get((region, quarter, measure))
        row = {
            "region": region,
            "quarter": quarter,
            "measure": measure,
            "old_value": old_value,
            "new_value": new_value,
            "absolute_variance": None,
            "relative_variance": None,
            "status": "empty",
        }
        if old_value is not None and new_value is not None:
            absolute_variance = new_value - old_value
            row["absolute_variance"] = absolute_variance
            row["relative_variance"] = (
                absolute_variance / abs(old_value) if old_value != 0 else None
            )
            tolerance = max(ABSOLUTE_TOLERANCE, RELATIVE_TOLERANCE * abs(old_value))
            row["status"] = (
                "within_tolerance"
                if abs(absolute_variance) <= tolerance
                else "genuine_divergence"
            )
        elif old_value is not None:
            row["status"] = "missing_new"
        elif new_value is not None:
            row["status"] = "missing_old"
        comparisons.append(row)

    comparable = [row for row in comparisons if row["status"] in {"within_tolerance", "genuine_divergence"}]
    summary = {
        "population_count": len(population),
        "sampled_count": len(selected),
        "comparable_count": len(comparable),
        "missing_old_count": sum(row["status"] == "missing_old" for row in comparisons),
        "missing_new_count": sum(row["status"] == "missing_new" for row in comparisons),
        "within_tolerance_count": sum(row["status"] == "within_tolerance" for row in comparisons),
        "genuine_divergence_count": sum(row["status"] == "genuine_divergence" for row in comparisons),
        "max_absolute_variance": max((abs(row["absolute_variance"]) for row in comparable), default=None),
    }
    return {"summary": summary, "selected_keys": [
        {"region": key[0], "quarter": key[1], "measure": key[2]} for key in selected
    ], "comparisons": comparisons}
