# Kilnbrook July scheduler

This package builds a July crew-and-bay capacity workbook from the current Cranemoor booking feed, the frozen 1 June turnaround snapshot, the crew roster, the bay calendar, and the July staffing policy. It runs offline with Python 3.11 and openpyxl.

The supplied July run uses the module default, coverage. That is a coverage-led recommendation: it favors the greatest number of eligible July bookings. This is deliberate for Mirela's immediate accept-more-work decision. Use cost when the required comparison is the lowest labour cost after covering as many confirmed bookings as possible.

Run the packaged command from a folder containing the input files:

    python build_schedule.py \
      --bookings cranemoor_updated_bookings.xlsx \
      --turnaround turnaround_snapshot_2026-06-01.xlsx \
      --crew kilnbrook_crew_roster.xlsx \
      --bays kilnbrook_bay_calendar.xlsx \
      --policy july_staffing_policy.md \
      --objective coverage \
      --output kilnbrook_july_capacity.xlsx \
      --summary july_run_summary.json

The command writes the workbook and a JSON summary. It validates every source before replacing the workbook. A missing input raises FileNotFoundError; a structural or planning-data issue raises ValueError with the source and field to inspect.

For a Python workflow, import the callable directly:

    from build_schedule import DEFAULT_OBJECTIVE, plan

    summary = plan(
        "cranemoor_updated_bookings.xlsx",
        "turnaround_snapshot_2026-06-01.xlsx",
        "kilnbrook_crew_roster.xlsx",
        "kilnbrook_bay_calendar.xlsx",
        "july_staffing_policy.md",
        DEFAULT_OBJECTIVE,
        "kilnbrook_july_capacity.xlsx",
    )

summary is ready for standard-library JSON serialization. It contains the selected objective, scheduled booking IDs, unscheduled booking reasons, total labour hours and cost, coverage, and one daily-capacity record for every July date.

The scheduler reconciles to the highest revision of each booking ID, collapses identical duplicates, and uses the frozen turnaround lookup for occupied time and compatible bay class. Cancelled and outside-July demand is reported in the workbook's Data Quality section rather than treated as candidate demand. Every assigned person must hold every required certification; a blank roster certification is never eligible. Bay and crew intervals include turnaround and use half-open boundaries, so an exact hand-off is allowed.

Labour is rounded up to a quarter-hour separately for each crew-booking assignment before the person's hourly rate is applied. The workbook retains formula-driven assignment costs, summary figures, and daily roll-ups so a shift lead can review the plan without running the script.

The exact source columns, governed aliases, reason-code precedence, output schema, and objective tie-breaks are defined in automation_contract.md. The policy file is the authoritative location for the planning interval, staffing cap, and label vocabulary. The bounded exact search is intended for July planning decisions and is not a high-volume dispatch optimizer.
