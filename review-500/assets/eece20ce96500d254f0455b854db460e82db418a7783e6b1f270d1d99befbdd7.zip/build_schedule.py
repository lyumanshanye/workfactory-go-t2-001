"""Offline Kilnbrook July crew-and-bay scheduler.

The module is intentionally self-contained so it can be copied into the
three-member scheduler archive and run beside the supplied workbooks.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import tempfile
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_HALF_UP
from itertools import combinations
from pathlib import Path
from typing import Any, Iterable, Sequence

from openpyxl import Workbook, load_workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


DEFAULT_OBJECTIVE = "coverage"
REASON_CODES = (
    "NO_CERTIFIED_CREW",
    "NO_COMPATIBLE_BAY",
    "CREW_UNAVAILABLE",
    "RESOURCE_CONFLICT",
    "STAFFING_CAP",
    "NOT_SELECTED",
)
_REASON_RANK = {reason: index for index, reason in enumerate(REASON_CODES)}

_D0 = Decimal("0")
_D15 = Decimal("15")
_D60 = Decimal("60")
_D900 = Decimal("900")
_D1000000 = Decimal("1000000")


class _InputError(ValueError):
    """Internal marker used to attach source context consistently."""


def _fail(source: str, field: str, message: str) -> None:
    raise ValueError(f"{source}: {field}: {message}")


def _first_reason(*reasons: str) -> str:
    return min(reasons, key=lambda reason: _REASON_RANK[reason])


def _norm(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip().casefold()


def _header_norm(value: Any) -> str:
    text = _norm(value)
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def _display_id(value: Any, source: str, field: str) -> str:
    if value is None or (isinstance(value, str) and not value.strip()):
        _fail(source, field, "must be nonblank")
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def _clean_backticks(value: str) -> str:
    return value.strip().strip("`").strip().strip('"').strip("'").strip()


def _alias_tokens(value: str) -> list[str]:
    found = re.findall(r"`([^`]*)`", value)
    if found:
        return [_clean_backticks(item) for item in found if _clean_backticks(item)]
    return [
        _clean_backticks(item)
        for item in re.split(r"[,|]", value)
        if _clean_backticks(item)
    ]


@dataclass(frozen=True)
class Policy:
    start: date
    end: date
    status_aliases: dict[str, str]
    equipment_aliases: dict[str, str]
    bay_aliases: dict[str, str]
    certification_aliases: dict[str, str]
    availability_aliases: dict[str, str]
    certification_delimiter: str
    staffing_cap: int


@dataclass
class QualityEvent:
    source: str
    record: str
    field: str
    observed: str
    disposition: str
    details: str


@dataclass(frozen=True)
class Booking:
    booking_id: str
    revision: int
    status: str
    operation_date: date
    requested_start: datetime
    operation_end: datetime
    occupied_start: datetime
    occupied_end: datetime
    equipment_class: str
    required_crew_count: int
    required_certifications: tuple[str, ...]
    priority: int
    source_row: int


@dataclass(frozen=True)
class Turnaround:
    equipment_class: str
    pre_minutes: int
    post_minutes: int
    bay_class: str
    source_row: int


@dataclass(frozen=True)
class CrewRecord:
    employee_id: str
    employee_name: str
    date_value: date
    shift_start: datetime
    shift_end: datetime
    certifications: frozenset[str]
    hourly_rate: Decimal
    source_row: int


@dataclass(frozen=True)
class BayRecord:
    bay_id: str
    bay_class: str
    date_value: date
    window_start: datetime
    window_end: datetime
    availability: str
    source_row: int


@dataclass(frozen=True)
class AssignmentOption:
    booking_id: str
    bay_id: str
    employee_ids: tuple[str, ...]
    employee_rates: tuple[Decimal, ...]
    employee_names: tuple[str, ...]
    occupied_start: datetime
    occupied_end: datetime
    rounded_hours: Decimal
    labour_hours: Decimal
    labour_cost: Decimal

    @property
    def signature(self) -> tuple[Any, ...]:
        return (self.booking_id, self.bay_id, self.employee_ids)


@dataclass
class ParsedInputs:
    policy: Policy
    bookings: list[Booking]
    turnaround: dict[str, Turnaround]
    crew: list[CrewRecord]
    bays: list[BayRecord]
    quality: list[QualityEvent]


@dataclass
class SolvedPlan:
    objective: str
    selected: dict[str, AssignmentOption]
    candidates: list[Booking]
    provisional_excluded: list[Booking]
    all_bookings: list[Booking]
    total_hours: Decimal
    total_cost: Decimal
    priority: int
    options_by_booking: dict[str, list[AssignmentOption]]
    diagnostics: dict[str, str]
    daily_capacity: list[dict[str, Any]]
    staffing_cap: int


def _parse_policy(path: Path) -> Policy:
    source = path.name
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        _fail(source, "file", f"cannot read policy ({exc})")

    required_sections = (
        "## Planning window",
        "## Status vocabulary",
        "## Equipment and bay vocabulary",
        "## Certification vocabulary",
        "## Calendar labels",
        "## Staffing and time rules",
    )
    for section in required_sections:
        if section not in text:
            _fail(source, "section", f"missing required section {section!r}")

    def date_value(label: str) -> date:
        match = re.search(rf"{re.escape(label)}\s*:\s*`?([0-9]{{4}}-[0-9]{{2}}-[0-9]{{2}})", text, re.I)
        if not match:
            _fail(source, label, "missing ISO date")
        try:
            return date.fromisoformat(match.group(1))
        except ValueError:
            _fail(source, label, "invalid ISO date")
        raise AssertionError

    start = date_value("Start date")
    end = date_value("End date (exclusive)")
    if end <= start:
        _fail(source, "planning window", "end date must be after start date")

    def parse_alias_section(pattern: str, label_name: str) -> dict[str, str]:
        aliases: dict[str, str] = {}
        matches = re.findall(pattern, text, re.I | re.M)
        if not matches:
            _fail(source, label_name, "no governed labels found")
        for canonical, values in matches:
            canonical = _clean_backticks(canonical)
            tokens = [canonical] + _alias_tokens(values)
            for token in tokens:
                key = _norm(token)
                if not key:
                    continue
                prior = aliases.get(key)
                if prior is not None and prior != canonical:
                    _fail(source, label_name, f"alias {token!r} has conflicting meanings")
                aliases[key] = canonical
        return aliases

    statuses = parse_alias_section(r"^-\s*(Confirmed|Provisional|Cancelled)\s*:\s*(.+)$", "status vocabulary")
    equipment = parse_alias_section(r"^-\s*Equipment\s+`?([^`:]+?)`?\s*:\s*(.+)$", "equipment vocabulary")
    bays = parse_alias_section(r"^-\s*Bay class\s+`?([^`:]+?)`?\s*:\s*(.+)$", "bay vocabulary")
    certifications = parse_alias_section(
        r"^-\s*Certification\s+`?([^`:]+?)`?\s*:\s*(.+)$", "certification vocabulary"
    )
    availability: dict[str, str] = {}
    for canonical, values in re.findall(r"^-\s*(Available|Blackout)\s*:\s*(.+)$", text, re.I | re.M):
        canonical = canonical.casefold()
        for token in [canonical] + _alias_tokens(values):
            key = _norm(token)
            if key:
                prior = availability.get(key)
                if prior is not None and prior != canonical:
                    _fail(source, "calendar labels", f"alias {token!r} has conflicting meanings")
                availability[key] = canonical
    if not availability:
        _fail(source, "calendar labels", "no availability aliases found")

    delimiter_match = re.search(r"Certification fields use\s+([^ ]+)\s*-\s*delimited", text, re.I)
    delimiter = ";"
    if delimiter_match:
        candidate = _clean_backticks(delimiter_match.group(1)).casefold()
        if candidate == "semicolon":
            delimiter = ";"
        elif candidate == "comma":
            delimiter = ","
        elif candidate:
            delimiter = candidate[0]

    cap_match = re.search(r"Maximum concurrent assigned headcount\s*:\s*`?(-?[0-9]+)", text, re.I)
    if not cap_match:
        _fail(source, "staffing cap", "missing maximum concurrent assigned headcount")
    cap = int(cap_match.group(1))
    if cap <= 0:
        _fail(source, "staffing cap", "must be positive")

    return Policy(start, end, statuses, equipment, bays, certifications, availability, delimiter, cap)


def _canonical(value: Any, aliases: dict[str, str], source: str, field: str) -> tuple[str, bool]:
    key = _norm(value)
    if not key:
        _fail(source, field, "blank governed label")
    canonical = aliases.get(key)
    if canonical is None:
        _fail(source, field, f"unknown governed label {value!r}")
    return canonical, str(value).strip() != canonical


def _decimal(value: Any, source: str, field: str) -> Decimal:
    if value is None or (isinstance(value, str) and not value.strip()):
        _fail(source, field, "blank numeric value")
    if isinstance(value, bool):
        _fail(source, field, "boolean is not numeric")
    try:
        if isinstance(value, Decimal):
            result = value
        elif isinstance(value, (int, float)):
            if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
                _fail(source, field, "must be finite")
            result = Decimal(str(value))
        else:
            result = Decimal(str(value).strip().replace(",", ""))
    except (InvalidOperation, ValueError):
        _fail(source, field, f"invalid numeric value {value!r}")
    if not result.is_finite():
        _fail(source, field, "must be finite")
    return result


def _integer(value: Any, source: str, field: str, minimum: int | None = None) -> int:
    result = _decimal(value, source, field)
    if result != result.to_integral_value():
        _fail(source, field, "must be an integer")
    number = int(result)
    if minimum is not None and number < minimum:
        _fail(source, field, f"must be at least {minimum}")
    return number


def _parse_date(value: Any, source: str, field: str) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        # openpyxl normally converts date-formatted serials, but accepting a
        # serial makes the validator useful with minimally authored fixtures.
        try:
            base = date(1899, 12, 30)
            return base + timedelta(days=float(value))
        except (OverflowError, ValueError):
            _fail(source, field, f"invalid date {value!r}")
    text = str(value).strip()
    for parser in (
        lambda x: date.fromisoformat(x),
        lambda x: datetime.strptime(x, "%m/%d/%Y").date(),
        lambda x: datetime.strptime(x, "%d/%m/%Y").date(),
    ):
        try:
            return parser(text)
        except (ValueError, TypeError):
            continue
    _fail(source, field, f"invalid date {value!r}")
    raise AssertionError


def _parse_time(value: Any, source: str, field: str, anchor: date) -> datetime:
    if isinstance(value, datetime):
        return value.replace(tzinfo=None)
    if isinstance(value, time):
        return datetime.combine(anchor, value.replace(tzinfo=None))
    if isinstance(value, date):
        _fail(source, field, "date supplied where time was required")
    if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        fraction = _decimal(value, source, field)
        if fraction < 0 or fraction >= 1:
            _fail(source, field, "numeric time must be in [0, 1)")
        micros = int((fraction * Decimal(86400) * _D1000000).to_integral_value(ROUND_HALF_UP))
        return datetime.combine(anchor, time(0, 0)) + timedelta(microseconds=micros)
    text = str(value).strip()
    # Explicit datetimes are useful for the cross-midnight boundary cases.
    try:
        parsed = datetime.fromisoformat(text)
        return parsed.replace(tzinfo=None)
    except ValueError:
        pass
    for fmt in ("%H:%M", "%H:%M:%S", "%H:%M:%S.%f", "%I:%M %p", "%I:%M:%S %p"):
        try:
            return datetime.combine(anchor, datetime.strptime(text, fmt).time())
        except ValueError:
            continue
    _fail(source, field, f"invalid time {value!r}")
    raise AssertionError


def _duration_minutes(value: Any, source: str, field: str) -> Decimal:
    if isinstance(value, timedelta):
        result = Decimal(value.total_seconds()) / Decimal(60)
    elif isinstance(value, time):
        result = Decimal(value.hour * 60 + value.minute) + Decimal(value.second) / Decimal(60)
    elif isinstance(value, str) and ":" in value.strip():
        parts = value.strip().split(":")
        if len(parts) not in (2, 3):
            _fail(source, field, f"invalid duration {value!r}")
        try:
            hours = Decimal(parts[0])
            minutes = Decimal(parts[1])
            seconds = Decimal(parts[2]) if len(parts) == 3 else _D0
            result = hours * _D60 + minutes + seconds / _D60
        except InvalidOperation:
            _fail(source, field, f"invalid duration {value!r}")
    else:
        result = _decimal(value, source, field)
    if result <= 0:
        _fail(source, field, "must be greater than zero")
    return result


def _add_minutes(moment: datetime, minutes: Decimal) -> datetime:
    micros = int((minutes * _D60 * _D1000000).to_integral_value(ROUND_HALF_UP))
    return moment + timedelta(microseconds=micros)


def _hours_between(start: datetime, end: datetime) -> Decimal:
    micros = Decimal((end - start).total_seconds()) * _D1000000
    return micros / (Decimal(3600) * _D1000000)


def _rounded_quarter_hours(start: datetime, end: datetime) -> Decimal:
    if end <= start:
        raise ValueError("occupied interval must have positive duration")
    micros = (end - start).days * 86400 * 1000000 + (end - start).seconds * 1000000 + (end - start).microseconds
    units = (micros + 900 * 1000000 - 1) // (900 * 1000000)
    return Decimal(units) / Decimal(4)


def _fmt_decimal(value: Decimal, places: int) -> float:
    quantum = Decimal(1).scaleb(-places)
    return float(value.quantize(quantum, rounding=ROUND_HALF_UP))


def _duration_to_excel_hours(value: Decimal) -> float:
    return float(value)


def _source_path(value: str | os.PathLike[str], label: str) -> Path:
    path = Path(value)
    if not path.exists():
        raise FileNotFoundError(f"missing required input {label}: {path}")
    if not path.is_file():
        raise FileNotFoundError(f"required input {label} is not a file: {path}")
    return path


def _load_table(path: Path, expected_sheet: str, required: dict[str, Sequence[str]], optional: dict[str, Sequence[str]] | None = None) -> list[dict[str, Any]]:
    source = path.name
    optional = optional or {}
    try:
        wb = load_workbook(path, read_only=True, data_only=False)
    except Exception as exc:  # openpyxl exposes several parser exception types
        _fail(source, "workbook", f"cannot parse ({exc})")
    sheet_name = next((name for name in wb.sheetnames if name.casefold() == expected_sheet.casefold()), None)
    if sheet_name is None:
        _fail(source, "sheet", f"missing required sheet {expected_sheet!r}")
    ws = wb[sheet_name]
    header_row = None
    columns: dict[str, int] = {}
    all_aliases: dict[str, tuple[str, str]] = {}
    for key, aliases in {**required, **optional}.items():
        for alias in aliases:
            all_aliases[_header_norm(alias)] = (key, alias)
    for row_number, row in enumerate(ws.iter_rows(values_only=True), start=1):
        found: dict[str, int] = {}
        for index, value in enumerate(row):
            match = all_aliases.get(_header_norm(value))
            if match is not None:
                key = match[0]
                if key in found:
                    _fail(source, "header", f"duplicate column for {key!r} on sheet {sheet_name!r}")
                found[key] = index
        if all(key in found for key in required):
            header_row = row_number
            columns = found
            break
    if header_row is None:
        missing = ", ".join(next(iter(aliases), key) for key, aliases in required.items())
        _fail(source, "header", f"required fields not found on sheet {sheet_name!r}; expected {missing}")

    records: list[dict[str, Any]] = []
    for row_number, row in enumerate(ws.iter_rows(min_row=header_row + 1, values_only=True), start=header_row + 1):
        values = {key: row[index] if index < len(row) else None for key, index in columns.items()}
        if all(value is None or (isinstance(value, str) and not value.strip()) for value in values.values()):
            continue
        values["_row"] = row_number
        records.append(values)
    wb.close()
    return records


def _quality(quality: list[QualityEvent], source: str, record: Any, field: str, observed: Any, disposition: str, details: str) -> None:
    quality.append(QualityEvent(source, str(record), field, "" if observed is None else str(observed), disposition, details))


def _parse_certifications(value: Any, policy: Policy, source: str, field: str, allow_blank: bool) -> tuple[tuple[str, ...], bool]:
    if value is None or (isinstance(value, str) and not value.strip()):
        if allow_blank:
            return (), False
        return (), False
    text = str(value)
    pieces = text.split(policy.certification_delimiter)
    if any(not piece.strip() for piece in pieces):
        _fail(source, field, "contains an empty certification token")
    result: list[str] = []
    changed = False
    for piece in pieces:
        canonical, was_changed = _canonical(piece, policy.certification_aliases, source, field)
        changed = changed or was_changed
        if canonical not in result:
            result.append(canonical)
    return tuple(sorted(result)), changed


def _check_order(start: datetime, end: datetime, source: str, field: str) -> None:
    if end <= start:
        _fail(source, field, "end must be strictly after start")


def _booking_table(path: Path) -> list[dict[str, Any]]:
    return _load_table(
        path,
        "Bookings",
        {
            "booking_id": ("Booking ID", "Booking_ID", "ID"),
            "revision": ("Revision", "Rev"),
            "status": ("Status", "Booking Status"),
            "operation_date": ("Operation Date", "Date"),
            "requested_start": ("Requested Start", "Start Time"),
            "duration": ("Operation Duration (minutes)", "Operation Duration Minutes", "Duration Minutes"),
            "equipment": ("Equipment Class", "Equipment"),
            "crew_count": ("Required Crew Count", "Crew Count", "Required Crew"),
            "certifications": ("Required Certifications", "Certifications", "Required Certification"),
            "priority": ("Priority", "Booking Priority"),
        },
        {
            "notes": ("Notes", "Note"),
            "requested_end": ("Requested End", "Operation End", "End Time"),
            "legacy_pre": ("Requested Pre-turnaround (minutes)", "Requested Pre Turnaround Minutes", "Legacy Pre Minutes"),
            "legacy_post": ("Requested Post-turnaround (minutes)", "Requested Post Turnaround Minutes", "Legacy Post Minutes"),
            "legacy_bay": ("Requested Bay Class", "Legacy Bay Class"),
        },
    )


def _turnaround_table(path: Path) -> list[dict[str, Any]]:
    return _load_table(
        path,
        "Turnaround",
        {
            "equipment": ("Equipment Class", "Equipment"),
            "pre": ("Pre-turnaround (minutes)", "Pre Turnaround Minutes", "Pre Minutes"),
            "post": ("Post-turnaround (minutes)", "Post Turnaround Minutes", "Post Minutes"),
            "bay_class": ("Compatible Bay Class", "Bay Class", "Compatible Class"),
        },
        {"notes": ("Notes", "Note")},
    )


def _crew_table(path: Path) -> list[dict[str, Any]]:
    return _load_table(
        path,
        "Crew Roster",
        {
            "employee_id": ("Employee ID", "Employee_ID", "Worker ID"),
            "employee_name": ("Employee Name", "Name"),
            "date": ("Date", "Shift Date"),
            "shift_start": ("Shift Start", "Start Time"),
            "shift_end": ("Shift End", "End Time"),
            "certifications": ("Certifications", "Certification", "Certs"),
            "hourly_rate": ("Hourly Rate", "Rate", "Hourly Labour Rate"),
        },
        {"notes": ("Notes", "Note")},
    )


def _bay_table(path: Path) -> list[dict[str, Any]]:
    return _load_table(
        path,
        "Bay Calendar",
        {
            "bay_id": ("Bay ID", "Bay_ID", "Bay"),
            "bay_class": ("Bay Class", "Class"),
            "date": ("Date", "Calendar Date"),
            "window_start": ("Window Start", "Operating Start", "Start Time"),
            "window_end": ("Window End", "Operating End", "End Time"),
            "availability": ("Availability", "Status", "Availability Flag"),
        },
        {"notes": ("Notes", "Note")},
    )


def _parse_turnaround(path: Path, policy: Policy, quality: list[QualityEvent]) -> dict[str, Turnaround]:
    rows = _turnaround_table(path)
    result: dict[str, Turnaround] = {}
    source = path.name
    for row in rows:
        equipment, changed_e = _canonical(row.get("equipment"), policy.equipment_aliases, source, f"Equipment Class row {row['_row']}")
        bay_class, changed_b = _canonical(row.get("bay_class"), policy.bay_aliases, source, f"Compatible Bay Class row {row['_row']}")
        pre = _integer(row.get("pre"), source, f"Pre-turnaround (minutes) row {row['_row']}", 0)
        post = _integer(row.get("post"), source, f"Post-turnaround (minutes) row {row['_row']}", 0)
        record = Turnaround(equipment, pre, post, bay_class, int(row["_row"]))
        prior = result.get(equipment.casefold())
        if prior is not None:
            if (prior.pre_minutes, prior.post_minutes, prior.bay_class.casefold()) != (pre, post, bay_class.casefold()):
                _fail(source, f"Equipment Class {equipment!r}", "conflicting duplicate turnaround row")
            _quality(quality, source, equipment, "duplicate", row.get("equipment"), "DUPLICATE_COLLAPSED", "identical lookup row collapsed")
        else:
            result[equipment.casefold()] = record
        if changed_e:
            _quality(quality, source, f"row {row['_row']}", "Equipment Class", row.get("equipment"), "NORMALIZED_LABEL", f"normalized to {equipment}")
        if changed_b:
            _quality(quality, source, f"row {row['_row']}", "Compatible Bay Class", row.get("bay_class"), "NORMALIZED_LABEL", f"normalized to {bay_class}")
    if not result:
        _fail(source, "Turnaround", "lookup table has no records")
    return result


def _parse_bookings(path: Path, policy: Policy, turnaround: dict[str, Turnaround], quality: list[QualityEvent]) -> tuple[list[Booking], list[Booking]]:
    rows = _booking_table(path)
    source = path.name
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        booking_id = _display_id(row.get("booking_id"), source, f"Booking ID row {row['_row']}")
        revision = _integer(row.get("revision"), source, f"Revision for {booking_id} row {row['_row']}", 0)
        groups[booking_id].append({**row, "_booking_id": booking_id, "_revision": revision})

    active: list[Booking] = []
    all_active_records: list[Booking] = []
    for booking_id in sorted(groups):
        records = groups[booking_id]
        max_revision = max(record["_revision"] for record in records)
        controlling = [record for record in records if record["_revision"] == max_revision]
        if len(records) > len(controlling):
            for record in records:
                if record["_revision"] < max_revision:
                    _quality(quality, source, booking_id, "Revision", record["_revision"], "SUPERSEDED_REVISION", f"superseded by revision {max_revision}")

        parsed_signatures: list[tuple[Any, ...]] = []
        parsed_rows: list[dict[str, Any]] = []
        for row in controlling:
            status, changed_status = _canonical(row.get("status"), policy.status_aliases, source, f"Status for {booking_id} row {row['_row']}")
            operation_date = _parse_date(row.get("operation_date"), source, f"Operation Date for {booking_id} row {row['_row']}")
            parsed = {"status": status, "operation_date": operation_date}
            if changed_status:
                _quality(quality, source, booking_id, "Status", row.get("status"), "NORMALIZED_LABEL", f"normalized to {status}")

            # Scope/cancellation is resolved before parsing non-key demand
            # fields. This permits harmless malformed material on an excluded
            # or superseded source row.
            in_scope = policy.start <= operation_date < policy.end
            if status == "Cancelled" or not in_scope:
                parsed_rows.append({**row, **parsed, "_in_scope": in_scope})
                parsed_signatures.append((status, operation_date.isoformat()))
                continue

            equipment, changed_equipment = _canonical(row.get("equipment"), policy.equipment_aliases, source, f"Equipment Class for {booking_id} row {row['_row']}")
            duration = _duration_minutes(row.get("duration"), source, f"Operation Duration (minutes) for {booking_id} row {row['_row']}")
            crew_count = _integer(row.get("crew_count"), source, f"Required Crew Count for {booking_id} row {row['_row']}", 1)
            priority = _integer(row.get("priority"), source, f"Priority for {booking_id} row {row['_row']}", 0)
            certifications, changed_certs = _parse_certifications(
                row.get("certifications"), policy, source, f"Required Certifications for {booking_id} row {row['_row']}", True
            )
            requested_start = _parse_time(row.get("requested_start"), source, f"Requested Start for {booking_id} row {row['_row']}", operation_date)
            if requested_start.date() != operation_date:
                _fail(source, f"Requested Start for {booking_id} row {row['_row']}", "explicit datetime date differs from Operation Date")
            operation_end = _add_minutes(requested_start, duration)
            requested_end_value = row.get("requested_end")
            if requested_end_value is not None and (not isinstance(requested_end_value, str) or requested_end_value.strip()):
                supplied_end = _parse_time(
                    requested_end_value,
                    source,
                    f"Requested End for {booking_id} row {row['_row']}",
                    operation_date,
                )
                _check_order(requested_start, supplied_end, source, f"Requested End for {booking_id} row {row['_row']}")
                if supplied_end != operation_end:
                    _fail(
                        source,
                        f"Requested End for {booking_id} row {row['_row']}",
                        "does not agree with Requested Start plus Operation Duration (minutes)",
                    )
            lookup = turnaround.get(equipment.casefold())
            if lookup is None:
                _fail(source, f"Equipment Class for {booking_id} row {row['_row']}", f"no frozen turnaround snapshot row for {equipment!r}")
            occupied_start = _add_minutes(requested_start, Decimal(-lookup.pre_minutes))
            occupied_end = _add_minutes(operation_end, Decimal(lookup.post_minutes))
            _check_order(requested_start, operation_end, source, f"operation interval for {booking_id}")
            _check_order(occupied_start, occupied_end, source, f"occupied interval for {booking_id}")
            if crew_count > policy.staffing_cap:
                _fail(source, f"Required Crew Count for {booking_id} row {row['_row']}", f"exceeds staffing cap {policy.staffing_cap}")
            legacy_values = (
                row.get("legacy_pre"),
                row.get("legacy_post"),
                row.get("legacy_bay"),
            )
            if any(value is not None and (not isinstance(value, str) or value.strip()) for value in legacy_values):
                _quality(
                    quality,
                    source,
                    booking_id,
                    "Requested turnaround / bay",
                    " | ".join("" if value is None else str(value) for value in legacy_values),
                    "FROZEN_SNAPSHOT_USED",
                    f"used frozen {lookup.pre_minutes}/{lookup.post_minutes} minute turnaround and {lookup.bay_class} bay class",
                )
            if changed_equipment:
                _quality(quality, source, booking_id, "Equipment Class", row.get("equipment"), "NORMALIZED_LABEL", f"normalized to {equipment}")
            if changed_certs:
                _quality(quality, source, booking_id, "Required Certifications", row.get("certifications"), "NORMALIZED_LABEL", f"normalized to {'; '.join(certifications)}")
            parsed.update(
                {
                    "equipment": equipment,
                    "duration": duration,
                    "crew_count": crew_count,
                    "priority": priority,
                    "certifications": certifications,
                    "requested_start": requested_start,
                    "operation_end": operation_end,
                    "occupied_start": occupied_start,
                    "occupied_end": occupied_end,
                    "_in_scope": True,
                }
            )
            parsed_rows.append({**row, **parsed})
            parsed_signatures.append(
                (
                    status,
                    operation_date.isoformat(),
                    requested_start.isoformat(),
                    str(duration),
                    equipment.casefold(),
                    crew_count,
                    certifications,
                    priority,
                )
            )

        # A controlling duplicate must agree on all governing fields. For
        # excluded rows the key disposition fields are sufficient because the
        # remaining material is explicitly irrelevant at this stage.
        if len(set(parsed_signatures)) != 1:
            _fail(source, f"Booking ID {booking_id}", "conflicting duplicate rows at the controlling revision")
        if len(controlling) > 1:
            for _ in controlling[1:]:
                _quality(quality, source, booking_id, "Revision", max_revision, "DUPLICATE_COLLAPSED", "identical controlling row collapsed")

        chosen = parsed_rows[0]
        status = chosen["status"]
        operation_date = chosen["operation_date"]
        if status == "Cancelled":
            _quality(quality, source, booking_id, "Status", chosen.get("status"), "CANCELLED_EXCLUDED", "cancelled demand excluded from scheduling")
            continue
        if not chosen["_in_scope"]:
            _quality(quality, source, booking_id, "Operation Date", operation_date, "OUT_OF_SCOPE", "operation date is outside the July planning window")
            continue
        booking = Booking(
            booking_id=booking_id,
            revision=max_revision,
            status=status,
            operation_date=operation_date,
            requested_start=chosen["requested_start"],
            operation_end=chosen["operation_end"],
            occupied_start=chosen["occupied_start"],
            occupied_end=chosen["occupied_end"],
            equipment_class=chosen["equipment"],
            required_crew_count=chosen["crew_count"],
            required_certifications=tuple(chosen["certifications"]),
            priority=chosen["priority"],
            source_row=int(chosen["_row"]),
        )
        active.append(booking)
        all_active_records.append(booking)
    return sorted(active, key=lambda item: item.booking_id), all_active_records


def _parse_crew(path: Path, policy: Policy, quality: list[QualityEvent]) -> list[CrewRecord]:
    rows = _crew_table(path)
    source = path.name
    dedup: dict[tuple[Any, ...], CrewRecord] = {}
    relevant_start = policy.start - timedelta(days=1)
    relevant_end = policy.end
    for row in rows:
        employee_id = _display_id(row.get("employee_id"), source, f"Employee ID row {row['_row']}")
        employee_name = _display_id(row.get("employee_name"), source, f"Employee Name row {row['_row']}")
        row_date = _parse_date(row.get("date"), source, f"Date for employee {employee_id} row {row['_row']}")
        if not (relevant_start <= row_date <= relevant_end):
            continue
        shift_start = _parse_time(row.get("shift_start"), source, f"Shift Start for employee {employee_id} row {row['_row']}", row_date)
        shift_end = _parse_time(row.get("shift_end"), source, f"Shift End for employee {employee_id} row {row['_row']}", row_date)
        if shift_start.date() != row_date:
            _fail(source, f"Shift Start for employee {employee_id} row {row['_row']}", "explicit datetime date differs from Date")
        _check_order(shift_start, shift_end, source, f"shift for employee {employee_id} row {row['_row']}")
        certifications, changed = _parse_certifications(
            row.get("certifications"), policy, source, f"Certifications for employee {employee_id} row {row['_row']}", False
        )
        rate = _decimal(row.get("hourly_rate"), source, f"Hourly Rate for employee {employee_id} row {row['_row']}")
        if rate < 0:
            _fail(source, f"Hourly Rate for employee {employee_id} row {row['_row']}", "must not be negative")
        if changed:
            _quality(quality, source, employee_id, "Certifications", row.get("certifications"), "NORMALIZED_LABEL", f"normalized to {'; '.join(certifications)}")
        if not certifications:
            _quality(quality, source, employee_id, "Certifications", row.get("certifications"), "BLANK_CERTIFICATION_INELIGIBLE", "roster row cannot be assigned")
        record = CrewRecord(employee_id, employee_name, row_date, shift_start, shift_end, frozenset(certifications), rate, int(row["_row"]))
        key = (employee_id, row_date.isoformat(), shift_start, shift_end)
        prior = dedup.get(key)
        if prior is not None:
            governed_prior = (prior.employee_name, prior.certifications, prior.hourly_rate)
            governed_new = (employee_name, record.certifications, rate)
            if governed_prior != governed_new:
                _fail(source, f"Employee ID {employee_id} row {row['_row']}", "conflicting duplicate availability row")
            _quality(quality, source, employee_id, "Availability", row_date, "DUPLICATE_COLLAPSED", "identical availability row collapsed")
        else:
            dedup[key] = record
    return sorted(dedup.values(), key=lambda item: (item.employee_id, item.date_value, item.shift_start, item.shift_end))


def _parse_bays(path: Path, policy: Policy, quality: list[QualityEvent]) -> list[BayRecord]:
    rows = _bay_table(path)
    source = path.name
    dedup: dict[tuple[Any, ...], BayRecord] = {}
    relevant_start = policy.start - timedelta(days=1)
    relevant_end = policy.end
    for row in rows:
        bay_id = _display_id(row.get("bay_id"), source, f"Bay ID row {row['_row']}")
        bay_class, changed_class = _canonical(row.get("bay_class"), policy.bay_aliases, source, f"Bay Class for {bay_id} row {row['_row']}")
        row_date = _parse_date(row.get("date"), source, f"Date for bay {bay_id} row {row['_row']}")
        if not (relevant_start <= row_date <= relevant_end):
            continue
        window_start = _parse_time(row.get("window_start"), source, f"Window Start for bay {bay_id} row {row['_row']}", row_date)
        window_end = _parse_time(row.get("window_end"), source, f"Window End for bay {bay_id} row {row['_row']}", row_date)
        if window_start.date() != row_date:
            _fail(source, f"Window Start for bay {bay_id} row {row['_row']}", "explicit datetime date differs from Date")
        _check_order(window_start, window_end, source, f"window for bay {bay_id} row {row['_row']}")
        availability, changed_availability = _canonical(row.get("availability"), policy.availability_aliases, source, f"Availability for bay {bay_id} row {row['_row']}")
        if changed_class:
            _quality(quality, source, bay_id, "Bay Class", row.get("bay_class"), "NORMALIZED_LABEL", f"normalized to {bay_class}")
        if changed_availability:
            _quality(quality, source, bay_id, "Availability", row.get("availability"), "NORMALIZED_LABEL", f"normalized to {availability}")
        record = BayRecord(bay_id, bay_class, row_date, window_start, window_end, availability, int(row["_row"]))
        key = (bay_id, row_date.isoformat(), window_start, window_end)
        prior = dedup.get(key)
        if prior is not None:
            if (prior.bay_class.casefold(), prior.availability) != (bay_class.casefold(), availability):
                _fail(source, f"Bay ID {bay_id} row {row['_row']}", "conflicting duplicate calendar row")
            _quality(quality, source, bay_id, "Calendar", row_date, "DUPLICATE_COLLAPSED", "identical calendar row collapsed")
        else:
            dedup[key] = record
    return sorted(dedup.values(), key=lambda item: (item.bay_id, item.date_value, item.window_start, item.window_end, item.availability))


def _parse_inputs(bookings_path: Path, turnaround_path: Path, crew_path: Path, bays_path: Path, policy_path: Path) -> ParsedInputs:
    quality: list[QualityEvent] = []
    policy = _parse_policy(policy_path)
    turnaround = _parse_turnaround(turnaround_path, policy, quality)
    bookings, _ = _parse_bookings(bookings_path, policy, turnaround, quality)
    crew = _parse_crew(crew_path, policy, quality)
    bays = _parse_bays(bays_path, policy, quality)
    return ParsedInputs(policy, bookings, turnaround, crew, bays, quality)


def _overlap(start_a: datetime, end_a: datetime, start_b: datetime, end_b: datetime) -> bool:
    return start_a < end_b and start_b < end_a


def _contains(start: datetime, end: datetime, target_start: datetime, target_end: datetime) -> bool:
    return start <= target_start and end >= target_end


def _interval_hours(start: datetime, end: datetime) -> Decimal:
    if end <= start:
        return _D0
    return _hours_between(start, end)


def _merge_intervals(intervals: Iterable[tuple[datetime, datetime]]) -> list[tuple[datetime, datetime]]:
    ordered = sorted((start, end) for start, end in intervals if end > start)
    merged: list[tuple[datetime, datetime]] = []
    for start, end in ordered:
        if not merged or start > merged[-1][1]:
            merged.append((start, end))
        else:
            old_start, old_end = merged[-1]
            if end > old_end:
                merged[-1] = (old_start, end)
    return merged


def _subtract_intervals(base: Iterable[tuple[datetime, datetime]], blocked: Iterable[tuple[datetime, datetime]]) -> list[tuple[datetime, datetime]]:
    blocked_merged = _merge_intervals(blocked)
    result: list[tuple[datetime, datetime]] = []
    for start, end in _merge_intervals(base):
        cursor = start
        for block_start, block_end in blocked_merged:
            if block_end <= cursor:
                continue
            if block_start >= end:
                break
            if block_start > cursor:
                result.append((cursor, min(block_start, end)))
            cursor = max(cursor, block_end)
            if cursor >= end:
                break
        if cursor < end:
            result.append((cursor, end))
    return result


def _employee_choices(booking: Booking, crew: list[CrewRecord]) -> tuple[dict[str, CrewRecord], int, bool]:
    by_employee: dict[str, list[CrewRecord]] = defaultdict(list)
    required = set(booking.required_certifications)
    for record in crew:
        if not record.certifications:
            continue
        if not required.issubset(record.certifications):
            continue
        if _contains(record.shift_start, record.shift_end, booking.occupied_start, booking.occupied_end):
            by_employee[record.employee_id].append(record)
    choices: dict[str, CrewRecord] = {}
    for employee_id, records in by_employee.items():
        choices[employee_id] = min(records, key=lambda item: (item.hourly_rate, item.shift_start, item.shift_end, item.employee_name))
    certified_count = sum(
        1
        for record_id in {record.employee_id for record in crew if record.certifications}
        if any(required.issubset(record.certifications) for record in crew if record.employee_id == record_id)
    )
    return choices, certified_count, bool(by_employee)


def _bay_choices(booking: Booking, bays: list[BayRecord], required_bay_class: str) -> list[str]:
    grouped: dict[str, list[BayRecord]] = defaultdict(list)
    for record in bays:
        if record.bay_class.casefold() == required_bay_class.casefold():
            grouped[record.bay_id].append(record)
    choices: list[str] = []
    for bay_id, records in grouped.items():
        operating = [record for record in records if record.availability == "available" and _contains(record.window_start, record.window_end, booking.occupied_start, booking.occupied_end)]
        blackouts = [record for record in records if record.availability == "blackout"]
        if operating and not any(_overlap(record.window_start, record.window_end, booking.occupied_start, booking.occupied_end) for record in blackouts):
            choices.append(bay_id)
    return sorted(choices)


def _option_for(booking: Booking, bay_id: str, employee_ids: tuple[str, ...], employee_records: dict[str, CrewRecord]) -> AssignmentOption:
    rounded = _rounded_quarter_hours(booking.occupied_start, booking.occupied_end)
    rates = tuple(employee_records[item].hourly_rate for item in employee_ids)
    names = tuple(employee_records[item].employee_name for item in employee_ids)
    cost = sum((rounded * rate for rate in rates), _D0)
    return AssignmentOption(
        booking.booking_id,
        bay_id,
        tuple(sorted(employee_ids)),
        rates,
        names,
        booking.occupied_start,
        booking.occupied_end,
        rounded,
        rounded * Decimal(len(employee_ids)),
        cost,
    )


def _build_options(parsed: ParsedInputs, booking: Booking) -> tuple[list[AssignmentOption], str | None]:
    snapshot = parsed.turnaround.get(booking.equipment_class.casefold())
    if snapshot is None:
        # This normally fails during parsing, but retaining the diagnostic
        # makes the solver defensive for programmatically built fixtures.
        return [], "NO_COMPATIBLE_BAY"
    employee_records, certified_count, _ = _employee_choices(booking, parsed.crew)
    bay_ids = _bay_choices(booking, parsed.bays, snapshot.bay_class)
    blockers: list[str] = []
    if certified_count < booking.required_crew_count:
        blockers.append("NO_CERTIFIED_CREW")
    if not bay_ids:
        blockers.append("NO_COMPATIBLE_BAY")
    if len(employee_records) < booking.required_crew_count:
        blockers.append("CREW_UNAVAILABLE")
    if blockers:
        return [], _first_reason(*blockers)
    options: dict[tuple[str, tuple[str, ...]], AssignmentOption] = {}
    for employees in combinations(sorted(employee_records), booking.required_crew_count):
        for bay_id in bay_ids:
            option = _option_for(booking, bay_id, employees, employee_records)
            key = (bay_id, employees)
            prior = options.get(key)
            if prior is None or option.labour_cost < prior.labour_cost:
                options[key] = option
    result = sorted(options.values(), key=lambda item: (item.bay_id, item.employee_ids, item.labour_cost))
    if not result:
        return [], "CREW_UNAVAILABLE"
    return result, None


def _resource_conflict(option: AssignmentOption, selected: Sequence[AssignmentOption]) -> bool:
    for current in selected:
        if current.bay_id == option.bay_id and _overlap(current.occupied_start, current.occupied_end, option.occupied_start, option.occupied_end):
            return True
        if set(current.employee_ids).intersection(option.employee_ids) and _overlap(current.occupied_start, current.occupied_end, option.occupied_start, option.occupied_end):
            return True
    return False


def _staffing_ok(options: Sequence[AssignmentOption], cap: int) -> bool:
    events: list[tuple[datetime, int]] = []
    for option in options:
        events.append((option.occupied_start, len(option.employee_ids)))
        events.append((option.occupied_end, -len(option.employee_ids)))
    # End events precede start events at an equal boundary under half-open
    # semantics. The running count is checked after each event group.
    events.sort(key=lambda item: (item[0], 0 if item[1] < 0 else 1))
    active = 0
    for _, delta in events:
        active += delta
        if active > cap:
            return False
        if active < 0:
            return False
    return True


def _can_add(option: AssignmentOption, selected: Sequence[AssignmentOption], cap: int) -> tuple[bool, bool, bool]:
    resource = _resource_conflict(option, selected)
    if resource:
        return False, True, False
    cap_ok = _staffing_ok([*selected, option], cap)
    if not cap_ok:
        return False, False, True
    return True, False, False


def _assignment_signature(selected: Sequence[AssignmentOption]) -> tuple[Any, ...]:
    return tuple(sorted((option.booking_id, option.bay_id, option.employee_ids) for option in selected))


def _better(objective: str, candidate: tuple[int, int, Decimal, tuple[Any, ...]], current: tuple[int, int, Decimal, tuple[Any, ...]] | None) -> bool:
    if current is None:
        return True
    count, priority, cost, signature = candidate
    c_count, c_priority, c_cost, c_signature = current
    if objective == "coverage":
        if count != c_count:
            return count > c_count
        if priority != c_priority:
            return priority > c_priority
        if cost != c_cost:
            return cost < c_cost
        return signature < c_signature
    if count != c_count:
        return count > c_count
    if cost != c_cost:
        return cost < c_cost
    if priority != c_priority:
        return priority > c_priority
    return signature < c_signature


def _solve_selected(objective: str, candidates: list[Booking], options_by_booking: dict[str, list[AssignmentOption]], cap: int) -> dict[str, AssignmentOption]:
    ordered = sorted(candidates, key=lambda item: item.booking_id)
    best_score: tuple[int, int, Decimal, tuple[Any, ...]] | None = None
    best_selected: list[AssignmentOption] = []
    selected: list[AssignmentOption] = []

    # A simple exact search is appropriate for the deliberately bounded
    # planning fixture. The count bound prunes branches that cannot beat the
    # current optimum while retaining all tie-break candidates.
    def visit(index: int, priority: int, cost: Decimal) -> None:
        nonlocal best_score, best_selected
        remaining = len(ordered) - index
        if best_score is not None and len(selected) + remaining < best_score[0]:
            return
        if index >= len(ordered):
            signature = _assignment_signature(selected)
            score = (len(selected), priority, cost, signature)
            if _better(objective, score, best_score):
                best_score = score
                best_selected = list(selected)
            return
        booking = ordered[index]
        # Explore options first so a useful incumbent is obtained early;
        # final selection is still determined solely by the score tuple.
        for option in options_by_booking.get(booking.booking_id, []):
            allowed, _, _ = _can_add(option, selected, cap)
            if not allowed:
                continue
            selected.append(option)
            visit(index + 1, priority + booking.priority, cost + option.labour_cost)
            selected.pop()
        visit(index + 1, priority, cost)

    visit(0, 0, _D0)
    return {option.booking_id: option for option in best_selected}


def _daily_available(bays: list[BayRecord], policy: Policy) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    current = policy.start
    while current < policy.end:
        day_start = datetime.combine(current, time.min)
        day_end = day_start + timedelta(days=1)
        by_bay: dict[str, list[BayRecord]] = defaultdict(list)
        for bay in bays:
            if _overlap(bay.window_start, bay.window_end, day_start, day_end):
                by_bay[bay.bay_id].append(bay)
        available = _D0
        for day_records in by_bay.values():
            operating = []
            blackouts = []
            for record in day_records:
                clipped = (max(record.window_start, day_start), min(record.window_end, day_end))
                if record.availability == "available":
                    operating.append(clipped)
                else:
                    blackouts.append(clipped)
            for start, end in _subtract_intervals(operating, blackouts):
                available += _interval_hours(start, end)
        records.append({"date": current.isoformat(), "scheduled": 0, "available_bay_hours": _fmt_decimal(available, 3), "used_bay_hours": 0.0})
        current += timedelta(days=1)
    return records


def _daily_used(records: list[dict[str, Any]], selected: dict[str, AssignmentOption], candidates: list[Booking], policy: Policy) -> None:
    by_id = {booking.booking_id: booking for booking in candidates}
    for item in records:
        day = date.fromisoformat(item["date"])
        day_start = datetime.combine(day, time.min)
        day_end = day_start + timedelta(days=1)
        used = _D0
        scheduled = 0
        for booking_id, option in selected.items():
            booking = by_id[booking_id]
            if booking.operation_date == day:
                scheduled += 1
            if _overlap(option.occupied_start, option.occupied_end, day_start, day_end):
                used += _interval_hours(max(option.occupied_start, day_start), min(option.occupied_end, day_end))
        item["scheduled"] = scheduled
        item["used_bay_hours"] = _fmt_decimal(used, 3)


def _solve(parsed: ParsedInputs, objective: str) -> SolvedPlan:
    candidates = [booking for booking in parsed.bookings if objective == "coverage" or booking.status == "Confirmed"]
    provisional_excluded = [booking for booking in parsed.bookings if objective == "cost" and booking.status == "Provisional"]
    options_by_booking: dict[str, list[AssignmentOption]] = {}
    diagnostics: dict[str, str] = {}
    for booking in parsed.bookings:
        options, diagnostic = _build_options(parsed, booking)
        options_by_booking[booking.booking_id] = options
        if diagnostic:
            diagnostics[booking.booking_id] = diagnostic
    selected = _solve_selected(objective, candidates, options_by_booking, parsed.policy.staffing_cap)
    total_hours = sum((option.labour_hours for option in selected.values()), _D0)
    total_cost = sum((option.labour_cost for option in selected.values()), _D0)
    total_priority = sum(next(booking.priority for booking in candidates if booking.booking_id == item) for item in selected)
    daily = _daily_available(parsed.bays, parsed.policy)
    _daily_used(daily, selected, parsed.bookings, parsed.policy)
    return SolvedPlan(
        objective,
        selected,
        candidates,
        provisional_excluded,
        parsed.bookings,
        total_hours,
        total_cost,
        total_priority,
        options_by_booking,
        diagnostics,
        daily,
        parsed.policy.staffing_cap,
    )


def _unscheduled(plan: SolvedPlan) -> list[dict[str, str]]:
    selected_ids = set(plan.selected)
    output: list[dict[str, str]] = []
    for booking in sorted(plan.all_bookings, key=lambda item: item.booking_id):
        if booking.booking_id in selected_ids:
            continue
        if plan.objective == "cost" and booking.status == "Provisional":
            reason = "NOT_SELECTED"
        elif booking.booking_id in plan.diagnostics:
            reason = plan.diagnostics[booking.booking_id]
        else:
            # An individually feasible booking omitted by the global optimum
            # is blocked by the chosen resource state or by the cap. The
            # contract gives resource occupancy precedence over the cap.
            options = plan.options_by_booking.get(booking.booking_id, [])
            resource_blocked = False
            cap_blocked = False
            for option in options:
                if _resource_conflict(option, list(plan.selected.values())):
                    resource_blocked = True
                elif not _staffing_ok([*plan.selected.values(), option], plan.staffing_cap):
                    cap_blocked = True
                else:
                    resource_blocked = True
            if resource_blocked:
                reason = _first_reason("RESOURCE_CONFLICT", "STAFFING_CAP")
            elif cap_blocked:
                reason = "STAFFING_CAP"
            else:
                reason = "RESOURCE_CONFLICT"
        output.append({"booking_id": booking.booking_id, "reason": reason})
    return output


def _summary_dict(plan: SolvedPlan) -> dict[str, Any]:
    denominator = len(plan.candidates)
    coverage = Decimal(len(plan.selected)) / Decimal(denominator) if denominator else _D0
    return {
        "objective": plan.objective,
        "scheduled_booking_ids": sorted(plan.selected),
        "unscheduled": _unscheduled(plan),
        "total_labor_hours": _fmt_decimal(plan.total_hours, 3),
        "total_labor_cost": _fmt_decimal(plan.total_cost, 2),
        "booking_coverage": _fmt_decimal(coverage, 4),
        "daily_capacity": [
            {
                "date": item["date"],
                "scheduled": int(item["scheduled"]),
                "available_bay_hours": float(item["available_bay_hours"]),
                "used_bay_hours": float(item["used_bay_hours"]),
            }
            for item in plan.daily_capacity
        ],
    }


def _recommendation(plan: SolvedPlan, comparison: SolvedPlan) -> str:
    selected_count = len(plan.selected)
    denominator = len(plan.candidates)
    comparison_count = len(comparison.selected)
    if plan.objective == "coverage":
        return (
            f"Recommended default: coverage-led plan, favoring greatest booking coverage. "
            f"It schedules {selected_count} of {denominator} eligible July bookings at "
            f"${_fmt_decimal(plan.total_cost, 2):,.2f}. The cost-led comparison schedules "
            f"{comparison_count} confirmed bookings at ${_fmt_decimal(comparison.total_cost, 2):,.2f}; "
            "coverage is the recommended reading because the current decision is whether constrained "
            "regional capacity can absorb more work."
        )
    return (
        f"Requested run: cost-led plan, favoring lowest labour cost after confirmed-demand coverage. "
        f"It schedules {selected_count} of {denominator} confirmed July bookings at "
        f"${_fmt_decimal(plan.total_cost, 2):,.2f}. The coverage-led comparison schedules "
        f"{comparison_count} eligible bookings at ${_fmt_decimal(comparison.total_cost, 2):,.2f}."
    )


_TITLE_FILL = PatternFill("solid", fgColor="1F4E78")
_SECTION_FILL = PatternFill("solid", fgColor="D9EAF7")
_HEADER_FILL = PatternFill("solid", fgColor="5B9BD5")
_PALE_GREEN = PatternFill("solid", fgColor="E2F0D9")
_PALE_AMBER = PatternFill("solid", fgColor="FFF2CC")
_PALE_RED = PatternFill("solid", fgColor="FCE4D6")
_WHITE_FONT = Font(color="FFFFFF", bold=True)
_BOLD = Font(bold=True)
_THIN_GREY = Side(style="thin", color="B7C9D6")
_BORDER = Border(bottom=_THIN_GREY)


def _title(ws: Any, title: str, subtitle: str, end_column: int) -> None:
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=end_column)
    cell = ws.cell(1, 1, title)
    cell.fill = _TITLE_FILL
    cell.font = Font(color="FFFFFF", bold=True, size=14)
    cell.alignment = Alignment(horizontal="left")
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=end_column)
    ws.cell(2, 1, subtitle)
    ws.cell(2, 1).font = Font(color="5A6B7A", italic=True)
    ws.cell(2, 1).alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[2].height = 28


def _headers(ws: Any, row: int, values: Sequence[str]) -> None:
    for column, value in enumerate(values, start=1):
        cell = ws.cell(row, column, value)
        cell.fill = _HEADER_FILL
        cell.font = _WHITE_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = _BORDER
    ws.row_dimensions[row].height = 30


def _set_widths(ws: Any, widths: Sequence[float]) -> None:
    for index, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(index)].width = width


def _write_summary_sheet(wb: Workbook, plan: SolvedPlan, comparison: SolvedPlan, schedule_last: int, unscheduled_last: int) -> None:
    ws = wb.create_sheet("Run Summary")
    _title(ws, "Kilnbrook Foundry | July crew and bay capacity", "Decision view generated from the reconciled Cranemoor bookings and the frozen 1 June turnaround snapshot.", 7)
    ws["A4"] = "Selected plan"
    ws["A4"].fill = _SECTION_FILL
    ws["A4"].font = _BOLD
    ws.merge_cells("A4:G4")
    rows = (
        ("Selected objective", plan.objective),
        ("Recommendation", _recommendation(plan, comparison)),
        ("", ""),
        ("Scheduled bookings", f"=SUM(Schedule!$S$5:$S${schedule_last})"),
        ("Eligible denominator", f"=B8+SUM(Unscheduled!$H$5:$H${unscheduled_last})"),
        ("Booking coverage", "=IF(B9=0,0,B8/B9)"),
        ("Total labour hours", f"=SUM(Schedule!$Q$5:$Q${schedule_last})"),
        ("Total labour cost", f"=ROUND(SUM(Schedule!$R$5:$R${schedule_last}),2)"),
        ("", ""),
        ("Coverage-mode comparison", f"{len(comparison.selected) if comparison.objective == 'coverage' else len(plan.selected)} scheduled bookings"),
        ("Cost-mode comparison", f"{_fmt_decimal(comparison.total_cost, 2) if comparison.objective == 'cost' else _fmt_decimal(plan.total_cost, 2):.2f} USD total labour cost"),
    )
    for row_number, (label, value) in enumerate(rows, start=5):
        ws.cell(row_number, 1, label)
        ws.cell(row_number, 2, value)
        if label:
            ws.cell(row_number, 1).font = _BOLD
            ws.cell(row_number, 1).border = _BORDER
            ws.cell(row_number, 2).border = _BORDER
    ws.merge_cells("B6:G6")
    ws["B6"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[6].height = 54
    ws["B10"].number_format = "0.0000%"
    ws["B11"].number_format = "0.000"
    ws["B12"].number_format = '$#,##0.00'
    ws["B15"].number_format = "0"
    ws["B16"].number_format = "0.00"
    ws["A5"].fill = _PALE_GREEN
    ws["A6"].fill = _PALE_GREEN
    _set_widths(ws, (28, 30, 16, 16, 16, 16, 16))
    ws.freeze_panes = "A5"
    ws.sheet_view.showGridLines = False
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_area = "A1:G16"


def _write_schedule_sheet(wb: Workbook, plan: SolvedPlan, policy: Policy) -> tuple[int, dict[str, int]]:
    ws = wb.create_sheet("Schedule")
    _title(ws, "Crew and bay assignments", "One row per assigned employee. Occupied time includes frozen turnaround; rounding and labour cost are spreadsheet formulas.", 20)
    headers = (
        "Booking ID",
        "Operation Date",
        "Status",
        "Revision",
        "Requested Start",
        "Requested End",
        "Occupied Start",
        "Occupied End",
        "Occupied Hours",
        "Bay ID",
        "Employee ID",
        "Employee Name",
        "Equipment Class",
        "Required Crew",
        "Priority",
        "Hourly Rate",
        "Rounded Labour Hours",
        "Labour Cost",
        "Booking Marker",
        "Source Row",
    )
    _headers(ws, 4, headers)
    for offset in range((policy.end - policy.start).days):
        column = 21 + offset
        cell = ws.cell(4, column, policy.start + timedelta(days=offset))
        cell.number_format = "mmm d"
        cell.fill = _HEADER_FILL
        cell.font = _WHITE_FONT
        cell.alignment = Alignment(horizontal="center")
        ws.column_dimensions[get_column_letter(column)].hidden = True

    booking_by_id = {booking.booking_id: booking for booking in plan.all_bookings}
    row_number = 5
    for booking_id in sorted(plan.selected):
        option = plan.selected[booking_id]
        booking = booking_by_id[booking_id]
        for index, employee_id in enumerate(option.employee_ids):
            values = (
                booking.booking_id,
                booking.operation_date,
                booking.status,
                booking.revision,
                booking.requested_start,
                booking.operation_end,
                booking.occupied_start,
                booking.occupied_end,
                f"=(H{row_number}-G{row_number})*24",
                option.bay_id,
                employee_id,
                option.employee_names[index],
                booking.equipment_class,
                booking.required_crew_count,
                booking.priority,
                float(option.employee_rates[index]),
                f"=ROUNDUP(I{row_number}*4,0)/4",
                f"=Q{row_number}*P{row_number}",
                f'=IF(COUNTIF($A$5:A{row_number},A{row_number})=1,1,0)',
                booking.source_row,
            )
            for column, value in enumerate(values, start=1):
                ws.cell(row_number, column, value)
            for offset in range((policy.end - policy.start).days):
                col = 21 + offset
                helper_date_cell = f"{get_column_letter(col)}$4"
                ws.cell(
                    row_number,
                    col,
                    f'=IF(AND($S{row_number}=1,$G{row_number}<{helper_date_cell}+1,$H{row_number}>{helper_date_cell}),(MIN($H{row_number},{helper_date_cell}+1)-MAX($G{row_number},{helper_date_cell}))*24,0)',
                )
            row_number += 1
    last = max(5, row_number - 1)
    for row in range(5, row_number):
        for column in range(1, 21):
            ws.cell(row, column).border = _BORDER
        ws.cell(row, 2).number_format = "dd mmm yyyy"
        for column in (5, 6, 7, 8):
            ws.cell(row, column).number_format = "dd mmm yyyy hh:mm"
        ws.cell(row, 9).number_format = "0.000"
        ws.cell(row, 16).number_format = '$#,##0.00'
        ws.cell(row, 17).number_format = "0.000"
        ws.cell(row, 18).number_format = '$#,##0.00'
        for column in range(21, 21 + (policy.end - policy.start).days):
            ws.cell(row, column).number_format = "0.000"
    ws.auto_filter.ref = f"A4:T{last}"
    ws.freeze_panes = "A5"
    ws.sheet_view.showGridLines = False
    _set_widths(ws, (16, 13, 13, 10, 20, 20, 20, 20, 14, 12, 14, 22, 19, 13, 10, 14, 20, 14, 14, 11))
    ws.conditional_formatting.add(f"R5:R{last}", CellIsRule(operator="greaterThan", formula=["0"], fill=_PALE_GREEN))
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_area = f"A1:T{last}"
    helper_columns = {
        (policy.start + timedelta(days=index)).isoformat(): 21 + index
        for index in range((policy.end - policy.start).days)
    }
    return last, helper_columns


def _write_unscheduled_sheet(wb: Workbook, plan: SolvedPlan) -> int:
    ws = wb.create_sheet("Unscheduled")
    _title(ws, "Eligible demand not scheduled", "Cancelled and out-of-window records are shown in Data Quality. This list contains only active July demand.", 8)
    _headers(
        ws,
        4,
        (
            "Booking ID",
            "Reason",
            "Status",
            "Operation Date",
            "Priority",
            "Revision",
            "Equipment Class",
            "Counts Toward Denominator",
        ),
    )
    booking_by_id = {booking.booking_id: booking for booking in plan.all_bookings}
    row_number = 5
    for record in _unscheduled(plan):
        booking = booking_by_id[record["booking_id"]]
        count = 1 if (plan.objective == "coverage" or booking.status == "Confirmed") else 0
        values = (
            booking.booking_id,
            record["reason"],
            booking.status,
            booking.operation_date,
            booking.priority,
            booking.revision,
            booking.equipment_class,
            count,
        )
        for column, value in enumerate(values, start=1):
            ws.cell(row_number, column, value)
            ws.cell(row_number, column).border = _BORDER
        ws.cell(row_number, 4).number_format = "dd mmm yyyy"
        if record["reason"] == "NOT_SELECTED":
            for column in range(1, 9):
                ws.cell(row_number, column).fill = _PALE_AMBER
        else:
            for column in range(1, 9):
                ws.cell(row_number, column).fill = _PALE_RED
        row_number += 1
    last = max(5, row_number - 1)
    ws.auto_filter.ref = f"A4:H{last}"
    ws.freeze_panes = "A5"
    ws.sheet_view.showGridLines = False
    _set_widths(ws, (16, 22, 13, 15, 10, 10, 20, 24))
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    ws.print_area = f"A1:H{last}"
    return last


def _daily_components(bays: list[BayRecord], policy: Policy) -> dict[str, tuple[Decimal, Decimal]]:
    components: dict[str, tuple[Decimal, Decimal]] = {}
    current = policy.start
    while current < policy.end:
        day_start = datetime.combine(current, time.min)
        day_end = day_start + timedelta(days=1)
        by_bay: dict[str, list[BayRecord]] = defaultdict(list)
        for bay in bays:
            if _overlap(bay.window_start, bay.window_end, day_start, day_end):
                by_bay[bay.bay_id].append(bay)
        opening = _D0
        available = _D0
        for records in by_bay.values():
            operating = []
            blackouts = []
            for record in records:
                clipped = (max(record.window_start, day_start), min(record.window_end, day_end))
                if record.availability == "available":
                    operating.append(clipped)
                else:
                    blackouts.append(clipped)
            opening += sum((_interval_hours(start, end) for start, end in _merge_intervals(operating)), _D0)
            available += sum((_interval_hours(start, end) for start, end in _subtract_intervals(operating, blackouts)), _D0)
        components[current.isoformat()] = (opening, opening - available)
        current += timedelta(days=1)
    return components


def _write_daily_sheet(wb: Workbook, plan: SolvedPlan, parsed: ParsedInputs, schedule_last: int, helper_columns: dict[str, int]) -> None:
    ws = wb.create_sheet("Daily Capacity")
    _title(ws, "Daily bay capacity", "Available hours are operating-window unions less blackout overlap. Used hours count each occupied bay interval once, without crew multiplication.", 7)
    _headers(
        ws,
        4,
        (
            "Date",
            "Scheduled Bookings",
            "Operating Window Hours",
            "Blackout Reduction",
            "Available Bay Hours",
            "Used Bay Hours",
            "Bay Use %",
        ),
    )
    components = _daily_components(parsed.bays, parsed.policy)
    for index, item in enumerate(plan.daily_capacity, start=5):
        date_value = date.fromisoformat(item["date"])
        opening, blackout = components[item["date"]]
        helper_col = get_column_letter(helper_columns[item["date"]])
        ws.cell(index, 1, date_value)
        ws.cell(index, 2, f'=SUMIFS(Schedule!$S$5:$S${schedule_last},Schedule!$B$5:$B${schedule_last},A{index})')
        ws.cell(index, 3, float(opening))
        ws.cell(index, 4, float(blackout))
        ws.cell(index, 5, f"=MAX(0,C{index}-D{index})")
        ws.cell(index, 6, "=SUM(Schedule!$" + helper_col + "$5:$" + helper_col + "$" + str(schedule_last) + ")")
        ws.cell(index, 7, f"=IF(E{index}=0,0,F{index}/E{index})")
        for column in range(1, 8):
            ws.cell(index, column).border = _BORDER
        ws.cell(index, 1).number_format = "ddd dd mmm"
        for column in (3, 4, 5, 6):
            ws.cell(index, column).number_format = "0.000"
        ws.cell(index, 7).number_format = "0.0%"
    last = 4 + len(plan.daily_capacity)
    ws.auto_filter.ref = f"A4:G{last}"
    ws.freeze_panes = "A5"
    ws.sheet_view.showGridLines = False
    _set_widths(ws, (16, 20, 24, 21, 22, 18, 13))
    ws.conditional_formatting.add(f"G5:G{last}", CellIsRule(operator="greaterThan", formula=["0.85"], fill=_PALE_RED))
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    ws.print_area = f"A1:G{last}"


def _write_quality_sheet(wb: Workbook, quality: list[QualityEvent]) -> None:
    ws = wb.create_sheet("Data Quality")
    _title(ws, "Reconciliation and quality record", "Records below show the source actions taken before the July schedule was generated.", 6)
    _headers(ws, 4, ("Source", "Record", "Field", "Observed", "Disposition", "Details"))
    for row_number, event in enumerate(
        sorted(quality, key=lambda item: (item.source, item.record, item.disposition, item.field, item.observed)),
        start=5,
    ):
        values = (event.source, event.record, event.field, event.observed, event.disposition, event.details)
        for column, value in enumerate(values, start=1):
            ws.cell(row_number, column, value)
            ws.cell(row_number, column).border = _BORDER
        if event.disposition in {"CANCELLED_EXCLUDED", "OUT_OF_SCOPE"}:
            fill = _PALE_AMBER
        elif "INELIGIBLE" in event.disposition:
            fill = _PALE_RED
        else:
            fill = _PALE_GREEN
        ws.cell(row_number, 5).fill = fill
    last = max(5, 4 + len(quality))
    ws.auto_filter.ref = f"A4:F{last}"
    ws.freeze_panes = "A5"
    ws.sheet_view.showGridLines = False
    _set_widths(ws, (39, 20, 24, 24, 30, 58))
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_area = f"A1:F{last}"


def _write_assumptions_sheet(wb: Workbook, parsed: ParsedInputs, plan: SolvedPlan, comparison: SolvedPlan) -> None:
    ws = wb.create_sheet("Assumptions")
    _title(ws, "Planning assumptions", "Policy controls are read from the supplied July staffing policy; frozen turnaround controls bay compatibility and occupancy.", 4)
    _headers(ws, 4, ("Topic", "Applied rule", "Selected run", "Comparison / source"))
    coverage_plan = plan if plan.objective == "coverage" else comparison
    cost_plan = plan if plan.objective == "cost" else comparison
    rows = (
        ("Default objective", DEFAULT_OBJECTIVE, plan.objective, "Coverage-led recommendation favors greatest booking coverage."),
        ("Planning interval", f"{parsed.policy.start.isoformat()} inclusive to {parsed.policy.end.isoformat()} exclusive", "", "july_staffing_policy.md"),
        ("Concurrent staffing cap", str(parsed.policy.staffing_cap), "", "Includes turnaround-only occupancy."),
        ("Turnaround source", "Frozen pre/post turnaround and compatible bay class", "", "turnaround_snapshot_2026-06-01.xlsx"),
        ("Certification rule", "Every assigned person holds every required complete token; blank roster certification is ineligible.", "", "Semicolon-delimited policy vocabulary."),
        ("Overlap rule", "Half-open occupied intervals; exact endpoint hand-offs are permitted.", "", "Crew and bay windows must fully contain occupied time."),
        ("Labour costing", "Each crew-booking occupied span is rounded upward to a quarter-hour before applying rate.", "", "USD; hours display to 0.001 and cost to 0.01."),
        ("Coverage comparison", f"{len(coverage_plan.selected)} scheduled of {len(coverage_plan.candidates)} eligible", f"${_fmt_decimal(coverage_plan.total_cost, 2):,.2f}", "Confirmed plus provisional demand."),
        ("Cost comparison", f"{len(cost_plan.selected)} scheduled of {len(cost_plan.candidates)} confirmed", f"${_fmt_decimal(cost_plan.total_cost, 2):,.2f}", "Provisional demand is NOT_SELECTED."),
    )
    for row_number, values in enumerate(rows, start=5):
        for column, value in enumerate(values, start=1):
            ws.cell(row_number, column, value)
            ws.cell(row_number, column).border = _BORDER
        ws.cell(row_number, 1).font = _BOLD
    ws.freeze_panes = "A5"
    ws.sheet_view.showGridLines = False
    _set_widths(ws, (25, 70, 28, 38))
    for row in range(5, 5 + len(rows)):
        ws.cell(row, 2).alignment = Alignment(wrap_text=True, vertical="top")
        ws.cell(row, 4).alignment = Alignment(wrap_text=True, vertical="top")
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_area = "A1:D13"


def _write_workbook(output_path: Path, parsed: ParsedInputs, plan: SolvedPlan, comparison: SolvedPlan) -> None:
    wb = Workbook()
    default = wb.active
    wb.remove(default)
    try:
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
    except AttributeError:
        pass
    schedule_last, helper_columns = _write_schedule_sheet(wb, plan, parsed.policy)
    unscheduled_last = _write_unscheduled_sheet(wb, plan)
    _write_summary_sheet(wb, plan, comparison, schedule_last, unscheduled_last)
    _write_daily_sheet(wb, plan, parsed, schedule_last, helper_columns)
    _write_quality_sheet(wb, parsed.quality)
    _write_assumptions_sheet(wb, parsed, plan, comparison)
    wb._sheets = [
        wb["Run Summary"],
        wb["Schedule"],
        wb["Unscheduled"],
        wb["Daily Capacity"],
        wb["Data Quality"],
        wb["Assumptions"],
    ]

    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            prefix=f".{output_path.stem}.",
            suffix=".xlsx",
            dir=output_path.parent,
            delete=False,
        ) as handle:
            temporary_name = handle.name
        wb.save(temporary_name)
        os.replace(temporary_name, output_path)
    except Exception:
        if temporary_name and os.path.exists(temporary_name):
            os.unlink(temporary_name)
        raise
    finally:
        wb.close()


def _normalized_objective(objective: Any) -> str:
    normalized = _norm(objective)
    if normalized not in {"coverage", "cost"}:
        raise ValueError(f"objective: expected 'coverage' or 'cost', received {objective!r}")
    return normalized


def plan(bookings_path, turnaround_path, crew_path, bays_path, policy_path, objective, output_path) -> dict:
    """Build an atomic workbook and return the contract's JSON-ready summary."""

    booking_file = _source_path(bookings_path, "cranemoor_updated_bookings.xlsx")
    turnaround_file = _source_path(turnaround_path, "turnaround_snapshot_2026-06-01.xlsx")
    crew_file = _source_path(crew_path, "kilnbrook_crew_roster.xlsx")
    bay_file = _source_path(bays_path, "kilnbrook_bay_calendar.xlsx")
    policy_file = _source_path(policy_path, "july_staffing_policy.md")
    normalized_objective = _normalized_objective(objective)
    parsed = _parse_inputs(booking_file, turnaround_file, crew_file, bay_file, policy_file)
    solved = _solve(parsed, normalized_objective)
    other_objective = "cost" if normalized_objective == "coverage" else "coverage"
    comparison = _solve(parsed, other_objective)
    summary = _summary_dict(solved)
    _write_workbook(Path(output_path), parsed, solved, comparison)
    return summary


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            prefix=f".{path.stem}.",
            suffix=".json",
            dir=path.parent,
            delete=False,
            mode="w",
            encoding="utf-8",
        ) as handle:
            temporary_name = handle.name
            json.dump(payload, handle, indent=2, sort_keys=False)
            handle.write("\n")
        os.replace(temporary_name, path)
    except Exception:
        if temporary_name and os.path.exists(temporary_name):
            os.unlink(temporary_name)
        raise


def _cli(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build the Kilnbrook July crew-and-bay capacity workbook.")
    parser.add_argument("--bookings", required=True, metavar="PATH")
    parser.add_argument("--turnaround", required=True, metavar="PATH")
    parser.add_argument("--crew", required=True, metavar="PATH")
    parser.add_argument("--bays", required=True, metavar="PATH")
    parser.add_argument("--policy", required=True, metavar="PATH")
    parser.add_argument("--objective", required=True, metavar="{coverage,cost}")
    parser.add_argument("--output", required=True, metavar="PATH")
    parser.add_argument("--summary", required=True, metavar="PATH")
    args = parser.parse_args(argv)
    summary = plan(
        args.bookings,
        args.turnaround,
        args.crew,
        args.bays,
        args.policy,
        args.objective,
        args.output,
    )
    _atomic_json(Path(args.summary), summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
