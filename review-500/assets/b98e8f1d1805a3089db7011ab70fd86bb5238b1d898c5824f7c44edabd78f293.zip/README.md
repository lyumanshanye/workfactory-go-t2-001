# Earnout calculator

Open `earnout_calculator.ipynb` in a Python 3.11 Jupyter environment and run all cells. The notebook is offline and includes the supplied `earnout_terms.json` and `quarterly_measurements.csv`.

The callable `calculate_earnout(quarter_rows, terms)` accepts a list of dictionaries and a parsed terms dictionary. See the notebook's assumptions and validation notes before using it for a new quarter.
