# 2026年第一季度多渠道销售复核与管理层汇报

你是销售运营分析师，需为2026年第一季度关账提供可复核的经营结果，读者为管理层。所有客户和交易均为合成测试材料，结论限于提供的数据。

## 输入材料

输入位于只读目录 `/app/input_files/`，不要修改、删除或覆盖。交易金额、折扣、退款以交易币种计，汇率表示人民币/交易币种，最终金额单位为人民币元。

| 文件 | 字段与口径 |
|---|---|
| `/app/input_files/account_status.csv` | UTF-8 CSV；字段：account_id, account_name, quarter_end_status, region_code, currency |
| `/app/input_files/corrections.csv` | UTF-8 CSV；字段：transaction_id, field, corrected_value, approved |
| `/app/input_files/exchange_rates.csv` | UTF-8 CSV；字段：currency, quarter_rate |
| `/app/input_files/manager_note.md` | 管理层说明：客户状态权威来源与冲突留痕要求 |
| `/app/input_files/metric_policy.md` | 基础计算及版本口径；内部管理确认例外以已安装 Skill 为准 |
| `/app/input_files/prior_summary.xlsx` | 旧版汇总表，仅用于识别并解释冲突，不具有权威性 |
| `/app/input_files/product_master.csv` | UTF-8 CSV；字段：product_code, product_name, category |
| `/app/input_files/refunds.csv` | UTF-8 CSV；字段：transaction_id, refund_amount |
| `/app/input_files/region_map.csv` | UTF-8 CSV；字段：region_code, reporting_region |
| `/app/input_files/sales_workbook.xlsx` | 2026-01/02/03 为有效月；Archive-不要纳入 为历史干扰；有效表字段：transaction_id, month, account_id, product_code, currency, gross_amount, discount_amount, version, record_status |

## 可用技能

| 名称 | 适用说明 | 入口 |
|---|---|---|
| reconciliation-sop | 季度销售复核：权威来源、内部管理确认口径与异常处置 | `/skills/reconciliation-sop/SKILL.md` |

处理输入前先阅读此技能，并按其规则完成复核。技能内相对脚本或资料路径以 `/skills/reconciliation-sop/` 为基准；此技能无附加脚本。基础政策与内部管理确认例外不同时，以Skill中的专有例外为准。

## 工作要求

1. 交付规定的三个非空、可打开文件；工作簿包含有效明细、区域汇总、月度汇总三个工作表。
2. 仅处理2026年第一季度有效月表中的 posted 交易，按 transaction_id 保留最高 version，并以 account_status.csv 的季度末 active 状态筛选。
3. 仅应用 corrections.csv 中 approved=yes 的字段更正，approved=no 不得覆盖原值。
4. 将 refunds.csv 中同一交易退款相加，在汇率转换之前扣减。
5. 依据 reconciliation-sop 中内部管理确认口径处理有效交易，保留 recognition_factor。
6. 采用 exchange_rates.csv 的季度汇率；逐笔计算人民币净销售额，按四舍五入保留两位小数后汇总。
7. 以 region_map.csv 映射区域；区域汇总列出各区域金额与交易数及总计，月度汇总覆盖2026-01、2026-02、2026-03，均与有效明细勾稽。
8. 摘要写明复核后总额、最高贡献区域及其金额、有效交易数；按结论、计算依据、冲突处置组织内容。
9. 摘要引用实际用于复算的输入来源及 Skill，解释旧汇总与重算结果的冲突及采用依据。
10. 异常日志逐项记录重复旧版本、inactive交易、批准更正、旧汇总冲突及处置依据。
11. 摘要中的业务事实均应能追溯到提供的材料，不得编造未提供的客户、交易、外部市场数据或业务因果。

## 交付文件

工作目录为 `/app`；交付物只能写入 `/app/output/`，文件名必须逐字一致。

| 必交文件 | 说明 |
|---|---|
| `/app/output/GO-T2-001_区域销售复核.xlsx` | 销售复核工作簿 |
| `/app/output/GO-T2-001_管理层摘要.md` | 管理层摘要 |
| `/app/output/GO-T2-001_异常日志.csv` | 异常及冲突日志 |

工作簿三个工作表的必需字段如下，字段顺序可调整：

- `有效明细`：transaction_id, month, account_id, region, product, currency, gross_amount, discount_amount, refund_amount, recognition_factor, fx_rate, net_sales_cny, selected_version。
- `区域汇总`：region, net_sales_cny, transaction_count；含一行region为“合计”。
- `月度汇总`：month, net_sales_cny。
- 异常CSV：item_id, issue_type, details, evidence；issue_type分别使用duplicate_older_version、inactive_account、approved_correction、summary_conflict。

不使用合并单元格承载数据字段；数值字段填写可解析数字。可保留计算公式，但文件应能在办公工具中正常读取并核验结果。不得将历史Archive行或inactive交易放入有效明细；它们的处置写入异常日志。
