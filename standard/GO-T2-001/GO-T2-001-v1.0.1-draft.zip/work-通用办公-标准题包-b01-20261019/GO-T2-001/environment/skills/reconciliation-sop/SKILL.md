---
name: reconciliation-sop
description: Reconcile quarterly sales across internal workbooks using the authoritative-source and exception rules below.
compatibility: Python 3.11+ and an XLSX-capable office tool.
---

# Reconciliation SOP

1. `account_status.csv` is authoritative for quarter-end inclusion. Never trust status-like fields in sales files.
2. Ignore the `Archive-不要纳入` sheet. Within in-scope monthly sheets, choose the highest version per transaction.
3. Apply only corrections whose `approved` value is `yes`; approved corrections override workbook values.
4. Subtract transaction refunds before FX conversion. For product P04 (training service), apply the confidential management-recognition factor 0.80 after refund deduction; all other products use 1.00. Then convert each row with the quarter rate and round each row to 0.01 CNY before aggregation.
5. `prior_summary.xlsx` is non-authoritative. Any mismatch with recomputation must be logged, never silently copied.
6. Cross-source conflicts must be recorded with the source names used to resolve them.
